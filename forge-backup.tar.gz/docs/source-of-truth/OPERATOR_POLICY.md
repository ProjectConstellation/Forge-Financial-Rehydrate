# Operator policy overrides (chronological; newest wins; overrides DIRECTIVE and DOSSIER where they conflict)
Recorded verbatim-in-substance from operator instructions in the build session. Only the operator may add entries.

## OP-001 — 2026-10-06T23:2xZ — Treasury = entire Coinbase balance
> "We can use all of it. Let's say whatever is in that balance is able to earn money and should aggressively earn as much as it can 24/7 always."

- Replaces the $20 treasury / $20 external-injection cap (DOSSIER §21, DIRECTIVE §6).
- FORGE's treasury = the full value of the configured Coinbase portfolio (USD + held assets), including future deposits and profits.
  At adoption: USD 28.27 (Default portfolio).
- Unchanged (hard constraints of both documents): trade only with positive expected net value after all costs; restart reserve 5–20% below $100,
  $25 floor at ≥ $100; no leverage; deterministic Risk Governor; readiness gate before LIVE; no forced trades.

## OP-002 — 2026-10-06 — Coinbase integration
- Use the operator's existing **personal** Coinbase account via the **Advanced Trade API** (CDP Secret API key, ECDSA). Do NOT require Coinbase Business.
- Initial key permissions: View + Trade (+ Receive allowed). No Transfer/Export/Manage. Adapter must stay modular (permissions / Agentic Wallet later).

## OP-003 — 2026-10-06 — Cash-out capability
- Build an operator-initiated, intelligent cash-out: Stage 1 = liquidate to USD in-account (Trade permission only). Stage 2 = transfer to operator-registered
  destinations only, when the operator explicitly authorizes Transfer on a key. Never initiated by the LLM or strategies.

## OP-004 — 2026-10-06 — Two-brain DeepSeek, real-time tools, hard thresholds, high-probability edges
> "We're going to leverage Deepseek V4.1 Pro at its maximum capability in compute and utilize tool function calls always to have real-time
> data at all times and have it generate new algorithms. If something doesn't work we have to have thresholds. We need to try something else.
> It must be aggressive but not lose money." · "the algorithms can be built to have ... 90% or higher statistics or probability of income"

- **Two brains**: `deepseek-v4-pro` at effort `max` = algorithm inventor / critic / postmortem (deep work). `deepseek-flash` = high-frequency
  tool-loop analyst. Both always work through typed tools fed with real-time data (never from memory).
- **90% rule**: no strategy receives real capital unless the posterior probability that its *net-of-all-costs* edge is positive is **≥ 0.90**
  (with minimum sample, walk-forward and robustness gates). Trades additionally require calibrated P(net win) above the strategy's threshold.
- **Thresholds → try something else**: hard per-trade stop, per-strategy demotion/retirement triggers, portfolio daily/weekly loss limits;
  every trip triggers an automatic DeepSeek-Pro postmortem and replacement challengers.
- **Aggressive capital use, capital preservation first**: full sizing on proven edges; losses capped by the thresholds above.
- DeepSeek pricing verified 2026-10-06 (USD / 1M tokens, off-peak | peak): Flash hit 0.003|0.006, miss 0.15|0.30, out 0.60|1.20;
  Pro hit 0.022|0.044, miss 0.66|1.32, out 1.98|3.96. Peak = 01–04 and 06–10 UTC Mon–Fri; all else off-peak.

## OP-005 — 2026-10-06 — Intelligent, always-live, multi-way earning
> "It must be intelligent. It must always be live in real time ... It should be able to find and earn money in many different ways not limited to one scope."

- FORGE runs continuously on live streams (WebSocket market data, live balances, live provider state); decisions are made on real-time data only.
- Earning is organized as pluggable **Income Rails** that all publish opportunities to one bus and compete for capital on the same
  true-net-value scale: spot trading families (many), maker liquidity/volatility harvesting, cross-sectional rotation, idle-capital yield
  (USD/USDC where eligible), and future rails (Kalshi/prediction markets, Base on-chain via Agentic Wallet, x402 machine-payable services,
  bounty/work marketplaces). The Venue Explorer continuously researches and proposes new rails.

## OP-006 — 2026-10-06 — CIO directive: optimize AI (don't minimize it), tiered escalation, Intelligence Attribution Ledger
Operator directive (verbatim core):
> Act as an elite Autonomous Multi-Strategy Quantitative Capital Growth CIO, Algorithmic Trading Architect, and Economic Opportunity Hunter whose sole
> mandate is to make FORGE exceptionally effective at autonomous capital growth. [...] Do NOT think narrowly in terms of stocks or one trading strategy.
> Continuously consider every legitimate, API-accessible way capital could earn more capital [...]. DeepSeek inference is not merely a cost or a trade
> predictor. Treat AI as a core economic intelligence layer [...]. Use DeepSeek V4.1 Flash continuously where economical. Escalate unusually valuable,
> complex, or ambiguous problems to the strongest DeepSeek reasoning model available, including V4 Pro/high reasoning when its expected information value
> justifies the additional cost. Use Modal aggressively [...] whenever expected economic benefit exceeds compute cost. [...] OBSERVE → DISCOVER →
> HYPOTHESIZE → CREATE → TEST → SHADOW → DEPLOY → MEASURE → LEARN → MUTATE → RETIRE → REINVEST → REPEAT. Every failed strategy becomes knowledge. Every
> successful strategy becomes reusable DNA. [...] Incorporate the strongest lessons from your earn-or-die-agent research [...] but do NOT allow academic
> caution to paralyze FORGE. Scale exposure progressively as evidence strengthens. Measure AI value broadly. [...] Build an Intelligence Attribution
> Ledger that traces inference/compute spend to downstream economic outcomes so FORGE learns where intelligence itself has the highest ROI. Your mission
> is not maximum trading frequency. Your mission is maximum sustainable net treasury growth after every cost. Take initiative. [...]

Operator clarification (same message): "Don't minimize AI. Optimize AI." The question is not "did the LLM make this trade profitable?" but
"did spending this intelligence ultimately increase FORGE's expected or realized net economic value?" (avoided losses, discovered strategies,
successors that survive, regime detection, venue discovery, compute routing). A no-LLM twin is at most one calibration signal, never a gate.

Canonical escalation loop:
market anomaly → Flash investigates → unusual? → Pro (max) investigates → Modal runs ~1,000 simulations → deterministic risk engine evaluates
→ execute / reject → result enters memory → routing policy learns from it.

Roles: Flash = continuous perception/orchestration · Pro (strongest available) = escalation brain · deterministic code = execution + risk ·
Modal = parallel computational muscle.

Adopted research takeaways (2026-10-06 brief): strategy-level metabolism/survival pressure, runway tiers for operating budgets, wallet-truth P&L,
$1 calibration trades, learned backtest→live haircut, pre-registered power targets, planted-signal (positive-control) evaluator tests, cost-ruler
versioning with automatic re-adjudication, loop/meltdown watchdog, stepping-stone archive, conduct rules in code, verified-independent-payer
admission for new income rails. Applied with progressive exposure scaling — caution must not paralyze.

## OP-007 — 2026-10-06 — PERMANENT ARCHITECTURE: two continuous concurrent loops (Earning + Improvement)
Permanent architectural requirement (not optional, not future):
1. **EARNING LOOP** — proven strategies keep operating while their real, fee-adjusted, risk-adjusted edge remains valid. Never interrupt a
   profitable incumbent merely because a newer idea exists. Capital stays deployed where evidence shows it is currently productive.
2. **IMPROVEMENT LOOP** — runs continuously in parallel with live earning; FORGE must never become strategically stagnant. Always capable of
   producing: new families, mutations, parameter improvements, component combinations, market hypotheses, indicators/features, asset/venue
   opportunities, regime variants, alternative execution methods, new legitimate API income rails.
- Every live strategy is an **incumbent, never a finished product**, continuously challenged by candidates:
  generated → simulated → backtested → walk-forward → shadow → compared → promoted or rejected.
- Strategy states: **PRODUCTION · CHALLENGER · EXPERIMENTAL · SHADOW · HIBERNATING · RETIRED** (+ QUARANTINED for invalid/bug results).
- Capital and compute continuously migrate toward the strongest demonstrated opportunities (real net performance, EV, uncertainty, liquidity,
  fees, slippage, drawdown, correlation, probability of ruin).
- Weak strategies never just disappear; FORGE decides: repair · mutate · reduce · hibernate (until regime returns) · combine · retire into
  permanent institutional memory (lineage, assumptions, results, failure reasons, applicable regimes retained).
- 24/7 = economically and intellectually active, not forced trading. Always at least one of: **EARNING → LEARNING → PREPARING TO EARN BETTER**.
- Implement by extending the existing architecture (no redesign).

## OP-008 — 2026-10-06 — Capital Regime + Capital Velocity Engine + Opportunity Cost Engine (enhancement, no redesign)
- Objective: ambitious treasury growth; while capital is small prefer opportunities that return capital + profit quickly for reinvestment.
  NOT a hard holding-time limit — exceptional longer-duration opportunities remain eligible; time enters scoring, not rules.
- Score every opportunity on: realistic earnings, confidence, capital required, time capital is unavailable (time-to-profit/liquidity),
  reinvestment speed, opportunities blocked by locked capital (opportunity cost), and whether smaller/faster compounding is superior.
- Treasury regimes (starting parameters, learnable/adjustable): SURVIVAL/ACCELERATION < $100 (rapid turnover, high-confidence short duration,
  intensive research; falling below $100 escalates intelligence/research/opportunity hunting — never reckless gambling) · GROWTH $100–$500
  (aggressive compounding, moderately longer durations, strengthen reserves + diversification) · EXPANSION $500+ (broader allocation, longer
  high-EV durations, multiple concurrent strategies, larger research budgets, portfolio construction).
- Capital Velocity Score in allocation decisions; Opportunity Cost Engine estimates EV lost while capital is locked.
- Auto-evolve with treasury: reserves, max allocation size, acceptable holding periods, research/inference budget, Modal allocation,
  concurrent strategies, strategy diversity, liquidity requirements.
- Never "grow quickly" via false confidence or bad bets; aggression comes from evidence, algorithms, intelligence, faster recycling, discovery.
- Governing principle: MAKE CAPITAL WORK HARD, RETURN IT QUICKLY WHEN POSSIBLE, REINVEST IT INTELLIGENTLY, AND NEVER LEAVE A BETTER
  OPPORTUNITY UNEXPLORED SIMPLY BECAUSE THE CURRENT RULES WERE STATIC.

## OP-009 — 2026-10-06 — Final Alpha & Acceleration Directive (enhancements, no redesign)
Immediate experimental objective: maximize the probability of positive REALIZED NET P&L within the first 24h of live operation while
preserving unlimited scalability. Never force trades to satisfy it.
1. Value-of-Information Intelligence Router — Flash continuous; escalate to strongest authorized DeepSeek reasoning when value is high,
   uncertainty economically significant, major failure diagnosis, potential new family, contradictory signals, or positive EVI. Optimize AI.
2. Opportunity Half-Life — every opportunity carries an estimated decay/half-life (seconds…days); prioritize by magnitude × urgency.
3. Execution Alpha — separate optimization of maker/taker, market/limit, entry timing, cancel timing, partial fills, liquidity, spread,
   slippage, depth, size impact, latency, realized fees. Preserve discovered alpha through execution.
4. Counterfactual Learning — no-trade, later entry, different size, second-best strategy, rejected-then-profitable, accepted-should-reject.
5. Confidence Calibration — empirical; recalibrate prediction classes automatically; sizing follows calibrated evidence only.
6. Evolution Safety — generated strategies run sandboxed and pass validation before meaningful capital. Evolution may NOT rewrite: wallet
   security, credential handling, immutable hard spending ceilings, emergency-stop behavior, the core Risk Governor.
7. Mission Treasury — three pools: GROWTH (compounding), SURVIVAL/PROTECTED (organism protection), MISSION (realized profit permanently
   removed from trading risk to fund North Star Imagine projects such as Ascend). Tiny-capital phase: prioritize compounding; extraction
   policy begins as growth makes it economically sensible (configurable, evolving).
8. Permanent operating principle — continuously optimize ALPHA · VELOCITY · INTELLIGENCE · EVOLUTION. No profitable algorithm is "finished".

## OP-010 — 2026-10-07 — Spending scales with confidence and earnings (no small-account friction)
> "Don't mistakenly create friction for this to be a system that only has a little bit of money to work with. As it earns money it has more
> money to invest and more money to use. ... spending scales based off of its confidence in how it's going to earn money. The idea is the most
> money the soonest, using the most advanced algorithms to ensure the highest returns possible."
- Inference and compute are INVESTMENTS allocated by expected value (attribution-ledger ROI per role/model/effort), not fixed small budgets.
- Spend rate scales up with measured value-per-$ and with realized earnings; scales down only when measured ROI is poor or funds run out.
- No fixed research timers: escalation is event/EV-driven (near-miss strategies, anomalies, failures, idle capital).
- Compute concentrates on near-miss candidates (closest to the evidence gate) — "racing" — to reach validated earning edges sooner.
- Hard limits that remain: cannot spend money that does not exist (DeepSeek balance; Modal monthly ceiling set by operator, raisable),
  and the evidence gate for capital (OP-004) — confidence must be earned, then capital and intelligence scale with it.

## OP-011 — 2026-10-07 — DeepSeek balance sentinel ($5 threshold → $10 refill)
Operator request: monitor DeepSeek balance continuously (lightweight); when it falls below $5, add exactly $10, once, intelligently.
Verified 2026-10-07: DeepSeek API has no top-up/payment endpoint (chat, models, balance only); OpenRouter's programmatic crypto
top-up is deprecated/removed. Credential-based website automation rejected (fragile, likely ToS violation, DIRECTIVE forbids bypassing
browser protections, puts card-spending power on the server). Implemented instead: Balance Sentinel — 5-min free balance polling;
below $5 → ONE "add $10" alert per episode (dashboard banner + optional ntfy push); detects top-ups and books them as inference funding;
tracks self-funding progress; graceful degradation (engine never stops). Upgrade path: provider-side auto-reload if available, or a
future programmatic payment rail (e.g. x402-capable inference provider paid from an allowlisted agentic wallet) when authorized.

## OP-012 — 2026-10-07 — FORGE MUST BE SELF-HEALING AT EVERY LAYER (+ corrections)
Four concurrent healing layers: (1) OPERATIONAL — supervise every process/worker/scheduler/stream/DB/Modal/provider connection; detect crashes,
hangs, stale heartbeats, memory/resource problems, WS disconnects, abnormal latency; restart/reconnect with exponential backoff + state
checkpoints; failures isolated from unrelated loops. (2) ECONOMIC — degraded live strategies lose capital automatically; strongest validated
challenger promoted; failed strategy + evidence preserved; DeepSeek diagnoses WHY; targeted mutations/new families (never random);
backtest→walk-forward→shadow→challenge→promote; profitable incumbents keep earning while challengers evolve. (3) DATA + EXECUTION — detect
stale/missing/contradictory/corrupt market & account data; Coinbase wallet/balance/order truth is authoritative; on uncertainty stop only the
affected execution, reconcile, rebuild local state, resume; every order idempotent. (4) INTELLIGENCE — DeepSeek never a single point of
failure; Flash for continuous perception; stronger reasoning when value/complexity justifies; if inference unavailable, deterministic
strategies/risk/execution continue and reasoning work queues for retry.
Corrections: no fixed concurrency (economic, dynamic: treasury, fees, quality, correlation); no mechanical breakeven exits (keep downside
protection; regime-aware trailing lets exceptional winners run); 50k candidates only useful with OOS/walk-forward, realistic costs and
multiple-testing controls; second-opinion model = calibrated evidence (measured on realized outcomes), not an automatic veto; continuous
probability/evidence-weighted allocation; keep smarter order placement + agreement boosting; Kalshi next after Coinbase is production-ready.
SELF-HEALING HEALTH SCORE on the dashboard: system, feed, execution, strategy, AI, treasury.
Operating law: always have a tested replacement strategy waiting whenever reasonably possible.
The organism is always EARNING, LEARNING, HEALING, or PREPARING TO EARN BETTER.

## OP-013 — 2026-10-07 — EXPAND THE COINBASE OPPORTUNITY SURFACE (discovery, not a static list)
FORGE's mandate covers EVERY legitimate, account-eligible, programmatically automatable opportunity through Coinbase and
compatible rails — not only Advanced spot. Build a dynamic Opportunity Surface Registry that periodically re-queries
capabilities, eligibility, APIs, fees, minimums, settlement delays and new products; a newly launched rail becomes a candidate
automatically. Minimum scope: Advanced spot (all eligible markets); Coinbase Prediction Markets (Kalshi-operated → official
Kalshi API, never browser automation); Coinbase stocks/ETFs (only via an official API; otherwise track as future rail + use
data); gold/commodities (PAXG, GLD when executable, gold event contracts); CDP onchain/DEX/agentic swaps/DeFi yield (explicit
wallet permissions + net-positive economics only); idle-capital yield (USDC rewards/staking) — idle money earns the best
legitimate low-friction return when not better deployed; any other current/future Coinbase product/API with positive EV.
Per rail: expected net return × calibrated probability × capital velocity × liquidity − fees − slippage − settlement/lockup
opportunity cost − inference/compute cost − risk penalty; the Capital Allocator decides where each dollar works. Crypto spot is
not preferred merely because it was integrated first. Never unsupported browser automation or bypassing platform controls; only
rails with legitimate APIs/SDKs/authorized access may execute automatically. Exploit CROSS-RAIL information (PAXG vs gold event
contracts, BTC spot vs BTC contracts, crypto vs related event markets, equity/ETF signals vs event contracts, other linked
instruments). Open-ended: research anything missed; incorporate and test. "FORGE goes where the best proven money is."
Follow-up instruction (same day): the probability model must be state-of-the-art and built for FORGE's profit — not a mere
"fair probability" model (implemented: HAR-RV + Garman–Klass (bias-corrected) + variance term structure + intraday seasonality +
filtered-historical-simulation tails + settlement-averaging + Bayesian stacked calibration vs market + maker-quote shadow).

## OP-014 — 2026-10-07 — Use every available credit (no hoarding), paced
Operator: "Regardless of whether money can be loaded or not, if there's a credit balance, the system's going to keep earning
money as best as it can" — use the DeepSeek balance even below the alert threshold; not burn it all at once.
Implemented: daily intelligence budget = max(ROI-driven burn, (balance − $0.10 floor) / 3-day runway) + earnings share;
hard floor lowered $0.25 → $0.10 (only to avoid mid-session failures that waste spend); LEAN tier below $0.30.
At $1.82: ≈ $0.57/day (was ≈ $0.24/day). Top-ups automatically raise the pace. The $5 refill alert (OP-011) stays.
Trading thresholds (readiness gate, ECR, haircut) are NOT changed by this policy.

## OP-015 — 2026-10-07 — Autonomous compute↔money scaling + wider net
Intelligence/compute spend scales automatically with available credit, measured value-per-$ and earnings (reinvestment);
top-ups are detected and used without human action. Build as many real, paper-tested earning rails as possible.

## OP-016 — 2026-10-07 — Operator holds Coinbase One Basic ($4.99/mo, 7-day trial, will keep)
Verified live: zero-fee benefit ($500/mo) EXCLUDES Coinbase Advanced/DEX/derivatives (no API path for FORGE); USDC rewards
3.75% APY unlimited, members-only → FORGE's idle cash can earn it once swept to USDC; +5% staking boost (no API);
no Advanced rebates on Basic. Stocks on Coinbase are commission-free (spread applies). Membership cost is the operator's
personal decision → incremental cost attributed to FORGE = $0; full cost shown separately.

## OP-017 — 2026-10-07 — Resource envelope: FORGE (incl. Hermes) ≤ 4 vCPU, ~4 GB RAM on the Command Center server
Heavy work goes to Modal ($30/month, via FORGE's compute governor). Hermes must run inside the same envelope and must pay
for itself (measured value-per-$ through the intelligence attribution ledger) — it exists to generate income.
Implemented: `forge.slice` (CPUQuota 400%, MemoryMax 4G, MemoryHigh 3.8G) containing forge.service (≤ 300% / 3G) and
forge-hermes.service. Supersedes the earlier 3 vCPU hard ceiling for the slice as a whole.

## OP-018 — 2026-10-07 — Operator Azure credit: Claude Opus 5.5 for Hermes for ~72 h (free compute)
Hermes uses Opus 5.5 (high reasoning) via the operator's Azure Foundry endpoint; treated as free compute (not a treasury
expense; list-price tracked only to measure value-per-$), paced over the window. Swap back to DeepSeek V4.1 Flash at any time
with zero recoding (`forge-hermes-mode deepseek`; docs/HERMES.md). All prompts/genomes live in FORGE.

## OP-019 — 2026-10-07 — "Get it live and actively earning" → idle cash earns USDC rewards now
Executed 2026-10-07 05:5x UTC: $23.27 USD → 23.27 USDC via Advanced Trade convert (fee $0, 1:1, trade 64eadfb9…,
COMPLETED); $5.00 USD kept liquid for the Coinbase One fee (first charge 2026-10-14). Rewards are verified hourly from wallet
truth (unexplained USDC increases); before any LIVE trading session FORGE converts USDC back to USD (live-start guard).
Spot strategy trading stays behind the readiness gate: no strategy has validated edge on clean data yet.

## OP-021 — 2026-10-07 — Starting-capital addendum: dynamic treasury regime (BOOTSTRAP → RESERVE)
Operator: until treasury reaches $50, FORGE may deploy essentially the entire treasury when calibrated evidence justifies it
(confidence-weighted: low → small, medium → moderate, high → large, exceptional → may use nearly all deployable capital);
never force all capital into one trade to chase the hourly target. At $50 a $25 protected reserve activates (first $25 =
survival capital, everything above deployable); reserve may grow with treasury.
Implemented: `src/forge/treasury/regime.py` — BOOTSTRAP while high-water mark < $50 (reserve $0); RESERVE latched once HWM
≥ $50 (reserve $25; ≥ $100 HWM → max($25, 25% of HWM)); tiers by INDEPENDENT-cluster evidence: LOW (n≥10, P≥0.80) 0.10
Kelly / 10% per cluster, MEDIUM (n≥10, P≥0.90, edge≥2¢/$) 0.25 / 25%, HIGH (n≥20, P≥0.95, ≥3¢) 0.50 / 50%, EXCEPTIONAL
(n≥40, P≥0.99) 1.0 / 90%. Circuit breakers (model-failure protection, not profit caps): bootstrap hourly 15% / daily 35% of
treasury; reserve regime 20% / 50% of deployable, never into the reserve.

## OP-022 — 2026-10-07 — Ambition directive: ≥ $1/h TRUE NET across the whole ecosystem, rising with capital and edge
Operator: optimise FORGE PROFIT VELOCITY (expected true net profit per capital-hour) across every legitimate rail; target
≥ $1/h true net, ratcheting upward as treasury and proven edge grow; never strategically stagnant.
Implemented: `src/forge/treasury/velocity.py` (loop every 5 min, `/api/velocity`, tool `get_profit_velocity`, headline in
every Hermes role brief): realized true-net $/h 1h/4h/24h (live fills + settlements + verified idle rewards − paid
intelligence − membership), expected $/h frontier (live-now / proven-LCB / potential) solved under capital-lock (Little's
law), drawdown-probability, Kelly-tier and liquidity constraints; capital utilization, recycle time, profit per deployed
dollar, opportunity cost, scaling curve ($28→$1000), and ranked levers (marginal $/h of capital, proof, flow). Target =
max($1/h, ratchet ×1.25 after each 24 h at/above target, proven frontier).
- OP-022 erratum (2026-10-07 16:40 UTC): the engine lives in `src/forge/treasury/profit_velocity.py` (`velocity.py` remains the OP-008 utilization hurdle / opportunity-cost module).

## OP-023 — 2026-10-07 — FORGE OPS COMMANDER (owner's remote operations agent)
Operator: a dedicated Hermes agent as the human-facing operations commander (SRE / AI-ops director / chief of staff),
reachable remotely with owner-only authenticated access, full audit, rate limits, prompt-injection protection, FORGE scope
only; executes authorised FORGE operations ("fix/restart/improve/deploy"), delegates to the 7 Hermes roles, explicit
confirmation for destructive / irreversible operations.
Implemented: separate Hermes profile + Linux user `forge-ops` + sandboxed `forge-ops.service` (FORGE secrets, DB and the
research profile invisible); Telegram (outbound long-polling, owner user-ID allowlist); tool surface = plugin
`hermes-forge-ops` only (shell/file/code/browser/delegation toolsets disabled); FORGE OPS API (`/api/ops/*`, own token,
loopback, audited, rate-limited); directives → role briefs → role reports; SAFE actions run, CONFIRM actions need a
one-time code delivered out-of-band to the owner's Telegram (never visible to the model); polkit allows only
restart/start of forge, forge-hermes, forge-tunnel. Code changes/deploys remain with the engineering channel.

## OP-024 — 2026-10-07 — FORGE EXECUTIVE OPS (upgrade of OP-023; owner's private natural-language control plane)
Operator: one private executive agent (assistant + CTO + quant CIO + chief of staff + ops commander) for debriefs, money
questions for any window, executive objectives ("make more money", "add <platform>", "fix it"), delegation to all roles,
owner transfers with one explicit confirmation, owner-only high-security mobile access, emergency revocation.
Implemented (same agent, upgraded): econ telemetry (10-s marks; windows 30 s … lifetime; LIVE vs PAPER; by strategy/rail;
costs), debrief, objective playbooks (grow_profit / integrate_platform / fix / custom → multi-role directives + engineering
tickets), credential intake `forge-exec-secret` (server-side, hidden input), transfers = FORGE portfolio → owner's own
Coinbase portfolio via official move_funds (preview → "CONFIRM TRANSFER $X" + authenticator code → execute → audit;
blocked while the key has can_transfer=false — unchanged until the owner authorises), TOTP 2FA with replay protection,
LOCKDOWN mode, hash-chained audit mirror, `forge-exec-revoke`. Channel: Signal recommended (E2E, UUID-bound); Telegram
supported (user-ID + private-chat bound).
