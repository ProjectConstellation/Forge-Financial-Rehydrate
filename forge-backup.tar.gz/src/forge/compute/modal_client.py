"""Compute Governor + Modal client (DOSSIER §4, §24–25; DIRECTIVE §4, §22; OP-009 §1).

Decides LOCAL_NORMAL vs LOCAL_SURGE vs MODAL_BURST by expected value of information and budget state:
GREEN <60% of the monthly Modal budget · YELLOW 60–85% · ORANGE 85–95% · RED >95% (only critical work).
Every job: parent id, timeout, cost estimate (core-seconds × list price + memory), ledger entry (true net P&L).
Market history is synced to the `forge-market` Volume so bursts read data locally inside Modal.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from forge.core.healing import Circuit
from forge.core.ids import new_id
from forge.persistence.db import dumps

log = logging.getLogger("forge.compute")


def _now() -> str:
    return datetime.now(UTC).isoformat()


class ComputeGovernor:
    def __init__(self, forge: Any) -> None:
        self.f = forge
        cfg = forge.s.compute.modal
        self.cfg = cfg
        self.budget = float(cfg.monthly_budget_usd)
        os.environ.setdefault("MODAL_ENVIRONMENT", cfg.environment)
        self.synced_at = 0.0
        self.cycles = 0
        self.burst_containers = 8
        self.burst_budget_s = 300.0
        self.available = True
        self.circuit = Circuit("modal", threshold=2, base_cooldown_s=600)

    # ------------------------------------------------------------------ budget state
    def month_spend(self) -> float:
        return float(self.f.db.scalar("SELECT COALESCE(SUM(CAST(est_cost_usd AS REAL)),0) FROM compute_jobs "
                                      "WHERE location = 'MODAL_BURST' AND ts_start >= ?",
                                      (datetime.now(UTC).strftime("%Y-%m-01"),)) or 0.0)

    def budget_state(self) -> str:
        u = self.month_spend() / self.budget if self.budget else 1.0
        return "GREEN" if u < 0.60 else "YELLOW" if u < 0.85 else "ORANGE" if u < 0.95 else "RED"

    def estimate_cost(self, containers: int, seconds: float, cpu: float = 2.0, mem_gib: float = 3.0) -> float:
        return containers * seconds * (cpu * float(self.cfg.cpu_core_second_usd) + mem_gib * float(self.cfg.memory_gib_second_usd))

    async def should_burst(self, forge: Any, interval: int) -> bool:
        """EVI-driven: burst when research value is high (no proven edge yet, demotions, brain escalation) and budget allows."""
        if not self.circuit.allow() or self.budget_state() == "RED":
            return False
        req = forge.db.kv_get("modal.experiment") or {}
        required = ("objective_id", "experiment_key", "evidence_version", "decision", "abort_criteria", "consumer")
        if not all(req.get(k) for k in required) or req.get("status") != "APPROVED":
            return False
        if req.get("consumer") != "evolution" or int(req.get("interval", 0)) != interval:
            return False
        if not 0 <= time.time() - float(req.get("ts", 0)) <= 3600:
            return False
        n, seconds = int(req.get("containers", 1)), float(req.get("timeout_s", 60))
        if not 1 <= n <= 16 or not 1 <= seconds <= 300:
            return False
        bound = self.estimate_cost(n, seconds) * 1.25
        if bound > float(req.get("max_cost_usd", 0)) or self.month_spend() + bound > self.budget:
            return False
        self.burst_containers, self.burst_budget_s = n, seconds
        return True

    # ------------------------------------------------------------------ data sync
    async def sync_volume(self) -> None:
        if time.time() - self.synced_at < 3 * 3600:
            return
        import modal

        def _upload() -> None:
            vol = modal.Volume.from_name("forge-market", environment_name=self.cfg.environment, create_if_missing=True)
            root = self.f.store.root
            with vol.batch_upload(force=True) as b:
                b.put_directory(str(root), "/candles")

        await asyncio.to_thread(_upload)
        self.synced_at = time.time()
        await self.f.say("Modal Lab", "Market history synced to Modal volume forge-market")

    # ------------------------------------------------------------------ bursts
    async def burst_search(self, forge: Any, interval: int, parents: list[Any], llm: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        if not await self.should_burst(forge, interval):
            raise RuntimeError("Modal requires an approved, bounded, consumable experiment")
        from forge.treasury.spend_admission import reserve, settle
        req = forge.db.kv_get("modal.experiment") or {}
        bound = self.estimate_cost(self.burst_containers, self.burst_budget_s) * 1.25
        admission = reserve(forge.db, provider="modal", owner="evolution", objective_id=req["objective_id"],
                            experiment_key=req["experiment_key"], max_cost_usd=bound,
                            budget_usd=self.budget, spent_usd=self.month_spend(), ttl_s=self.burst_budget_s + 300)
        if not admission["allowed"]:
            raise RuntimeError(f"Modal admission denied: {admission['reason']}")
        req.update(status="RUNNING", reservation_id=admission["reservation_id"])
        forge.db.kv_set("modal.experiment", req)
        import modal
        await self.sync_volume()
        fn = modal.Function.from_name("forge-research", "search", environment_name=self.cfg.environment)
        n = self.burst_containers
        pj = [g.model_dump(mode="json") for g in parents]
        fees = {"maker": float(forge.fees.maker), "taker": float(forge.fees.taker)}
        jid = new_id("job")
        t0 = time.time()
        forge.db.insert("compute_jobs", {"id": jid, "ts_start": _now(), "kind": f"evolution_{interval}", "location": "MODAL_BURST",
                                         "cpu": 2.0 * n, "memory_mb": 3072 * n, "status": "RUNNING",
                                         "strategy_ids": dumps([g.id for g in parents][:50]), "est_cost_usd": f"{bound:.8f}"})
        forge.status("Modal Lab", f"{n} workers · evolutionary tournament ({interval // 60}m)")
        forge.workers["modal"] = {"what": f"evolutionary tournament on {interval // 60}m data", "count": n, "since": time.time(),
                                  "where": "Modal cloud (2 vCPU-cores each)"}
        await forge.say("Modal Lab", f"Modal burst launched: {n} parallel workers × {self.burst_budget_s:.0f}s evolutionary "
                                     f"tournament on {interval // 60}m data (budget {self.budget_state()}, month ${self.month_spend():.2f}/${self.budget:.0f})")
        # different seeds and parent subsets per container (diversity); LLM genomes go to every container
        args = []
        for i in range(n):
            sub = pj[i::n] + pj[: max(0, 6 - len(pj[i::n]))]
            prior = int(forge.db.kv_get(f"stats.trials.{interval}", 0) or 0) * 1   # cumulative multiple-testing count
            seen, n_ex = forge.sealed_context(interval)
            args.append((interval, sub, fees, self.burst_budget_s, int(t0) + i * 7919, llm or [], prior, seen, n_ex))
        results: list[dict[str, Any]] = []
        try:
            async for r in fn.starmap.aio(args, return_exceptions=True):
                if isinstance(r, dict):
                    results.append(r)
                else:
                    log.warning("modal worker failed: %s", r)
        except Exception as e:
            forge.db.execute("UPDATE compute_jobs SET status='FAILED', ts_end=?, error=? WHERE id=?", (_now(), str(e)[:300], jid))
            settle(forge.db, admission["reservation_id"], None, jid, basis="failed_workers_provider_cost_unknown")
            forge.workers["modal"] = {"what": f"circuit {self.circuit.state} — local research fallback", "count": 0, "since": time.time(), "where": "Modal cloud"}
            await forge.say("Self-Healing", f"Modal burst failed ({str(e)[:100]}) → circuit {self.circuit.state}; local research "
                                            f"continues; retry in {self.circuit.cooldown_s:.0f}s", level="warn")
            raise
        if not results:
            forge.db.execute("UPDATE compute_jobs SET status='FAILED',ts_end=?,error=? WHERE id=?",
                             (_now(), "all workers failed; reserved estimate retained", jid))
            settle(forge.db, admission["reservation_id"], None, jid, basis="all_failed_provider_cost_unknown")
            self.circuit.failure("all workers failed")
            raise RuntimeError("all Modal workers failed")
        self.circuit.success()
        secs = sum(float(r.get("container_seconds", r.get("seconds", 0))) for r in results)
        cost = self.estimate_cost(1, secs) + self.estimate_cost(n - len(results), self.burst_budget_s)
        settle(forge.db, admission["reservation_id"], cost, jid, basis="internal_resource_estimate")
        forge.db.execute("UPDATE compute_jobs SET status='DONE', ts_end=?, duration_s=?, est_cost_usd=? WHERE id=?",
                         (_now(), time.time() - t0, f"{cost:.8f}", jid))
        if cost > 0:
            forge.ledger.record_opex(forge.book if forge.book in ("live", "paper") else "paper", "COMPUTE",
                                     Decimal(f"{cost:.8f}"), jid, memo=f"modal burst {n}x evolution_{interval}")
        merged: dict[str, Any] = {"candidates": [], "evaluated": 0, "seconds": time.time() - t0, "where": f"modal×{len(results)}",
                                  "best_fitness": max((r.get("best_fitness", 0) for r in results), default=0.0)}
        merged["sealed_start_ts"] = results[0].get("sealed_start_ts")
        merged["dataset"] = results[0].get("dataset")
        seen: set[str] = set()
        for r in results:
            merged["evaluated"] += r.get("evaluated", 0)
            for c in r.get("candidates", []):
                gid = c["genome"]["id"]
                if gid not in seen:
                    seen.add(gid)
                    merged["candidates"].append(c)
        forge.workers["modal"] = {"what": "scaled to zero (idle)", "count": 0, "since": time.time(), "where": "Modal cloud"}
        await forge.say("Modal Lab", f"Burst complete: {merged['evaluated']} genomes across {len(results)} containers, "
                                     f"{secs:.0f} container-s, est cost ${cost:.4f}")
        # Retain paid artifacts for replay and audit; consumption remains the evolution caller's responsibility.
        artifact = forge.s.research_dir / "modal" / f"{jid}.json"
        artifact.parent.mkdir(parents=True, exist_ok=True)
        artifact.write_text(dumps({"job_id": jid, "experiment": req, "cost_usd": cost,
                                   "cost_basis": "internal_resource_estimate", "results": merged}))
        req.update(status="RESULT_READY", job_id=jid, artifact=str(artifact))
        forge.db.kv_set("modal.experiment", req)
        return merged

    async def run(self, forge: Any) -> None:
        while not forge.stop_event.is_set():
            forge.sup.beat("compute")
            forge.status("Compute Governor", f"Modal {self.budget_state()} · month ${self.month_spend():.2f}/${self.budget:.0f} "
                                             f"· circuit {self.circuit.state}")
            # Economic phase: honor research requests from EconOrchestrator (RED ZONE / 8h trial)
            try:
                req = forge.db.kv_get("modal.research_request") or {}
                if req and not req.get("consumed") and (time.time() - float(req.get("ts") or 0)) < 3600:
                    if self.circuit.state != "OPEN" and await self.should_burst(forge, 3600):
                        parents = []
                        try:
                            parents = list(forge.reg.active())[:24]
                        except Exception:
                            parents = []
                        if parents:
                            forge.db.kv_set("modal.research_request", {**req, "consumed": True, "consumed_ts": time.time()})
                            await forge.say("Modal Lab", "Econ phase research burst (genome tournament / falsification)", level="info")
                            await self.burst_search(forge, 3600, parents)
                            forge.db.kv_set("econ.modal_research", {
                                "ts": time.time(), "launched": True, "status": "burst_launched",
                                "workloads": req.get("workloads"), "reason": req.get("reason"),
                            })
            except Exception as e:
                log.warning("econ modal request: %s", e)
            await asyncio.sleep(120)

    def summary(self) -> dict[str, Any]:
        return {"available": self.circuit.state != "OPEN", "circuit": self.circuit.state, "state": self.budget_state(), "month_usd": self.month_spend(),
                "budget_usd": self.budget, "admission": "explicit_experiment_required",
                "experiment": self.f.db.kv_get("modal.experiment"), "cost_basis": "internal_estimate"}


def attach_compute(forge: Any) -> None:
    if not forge.s.compute.modal.enabled:
        raise RuntimeError("Modal disabled in config")
    if not (forge.s.secrets.modal_token_id and forge.s.secrets.modal_token_secret):
        raise RuntimeError("MODAL_TOKEN_ID/SECRET not configured (CONFIG_REQUIRED)")
    forge.compute = ComputeGovernor(forge)
