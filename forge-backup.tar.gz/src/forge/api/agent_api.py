"""FORGE Agent API — the ONLY door between Hermes (or any external agent) and FORGE (Hermes dossier §4, OP-015/OP-017).

Auth: a dedicated agent token (`run/agent_token`, separate from the operator token). It is accepted ONLY on /api/agent/*,
never on operator controls (STOP ALL, cash-out, live mode). No exchange keys, no orders, no DB writes outside research
artifacts. Every call is attributed (intel_artifacts) and every Hermes token is costed into the same ledger as FORGE's
own brain (inference_calls + OPEX:INFERENCE) so Hermes must earn its keep under the same value-per-$ law.

Endpoints
  GET  /api/agent/tools          tool schemas (FORGE ToolRouter — identical tools to FORGE's own brain)
  POST /api/agent/tool           {name, args, role, session_id} → result (artifacts attributed to hermes_<role>)
  POST /api/agent/usage          {api_request_id, role, model, usage, session_id} → cost recorded (idempotent)
  GET  /api/agent/allow          ?role=&est_usd= → {"wake": bool, ...}  budget gate used by Hermes pre-run scripts
  GET  /api/agent/digest         ?since=<ts> → what changed (listing/rail/strategy/evidence/incidents) since a timestamp
"""

from __future__ import annotations

import hmac
import json
import secrets
import time
from decimal import Decimal
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request

HERMES_ROLES = ("governor", "alpha_inventor", "adversary", "critic", "doctor", "rail_hunter", "architect",
                "scout", "scientist", "prediction", "execution", "treasury", "intelligence", "ops")
HERMES_SHARE_PRIOR = 0.40          # share of the Intelligence Treasury pace Hermes may use before its value is measured


def agent_token(home: Path) -> str:
    p = home / "run" / "agent_token"
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(secrets.token_urlsafe(32))
        p.chmod(0o600)
    return p.read_text().strip()


def is_agent_request(req: Request, token: str) -> bool:
    a = req.headers.get("authorization", "")
    return a.startswith("Bearer ") and hmac.compare_digest(a[7:].strip(), token)


# External (non-DeepSeek) model list prices, USD per 1M tokens — used to MEASURE value-per-$ even when compute is free.
EXTERNAL_PRICES: dict[str, Any] = {}  # DeepSeek always uses configured provider prices and incurs real OPEX.


def hermes_spent_24h(db: Any, external: bool = False) -> float:
    from datetime import UTC, datetime, timedelta
    cut = (datetime.now(UTC) - timedelta(hours=24)).isoformat()
    cond = "model NOT LIKE 'deepseek%'" if external else "model LIKE 'deepseek%'"
    return float(db.scalar("SELECT COALESCE(SUM(CAST(cost_usd AS REAL)),0) FROM inference_calls "
                           f"WHERE agent LIKE 'hermes%' AND {cond} AND ts >= ?", (cut,)) or 0.0)


def credit_allowance(forge: Any, mode: dict[str, Any]) -> dict[str, Any]:
    """Free operator credit window (legacy; DeepSeek Flash is the active workforce): not a FORGE expense, but paced so it lasts the whole window."""
    from datetime import UTC, datetime
    start, hours, credit = float(mode["start"]), float(mode.get("hours", 72)), float(mode.get("credit_usd", 180))
    used = float(forge.db.scalar("SELECT COALESCE(SUM(CAST(cost_usd AS REAL)),0) FROM inference_calls WHERE agent LIKE "
                                 "'hermes%' AND model NOT LIKE 'deepseek%' AND ts >= ?",
                                 (datetime.fromtimestamp(start, UTC).isoformat(),)) or 0.0)
    elapsed_h = max((time.time() - start) / 3600, 0.0)
    left_h = max(hours - elapsed_h, 0.0)
    # pace: credit spread evenly over the window, with catch-up allowed (unused earlier budget is spendable later)
    allowed_so_far = credit * min(1.0, (elapsed_h + 2.0) / hours)
    return {"mode": "credit", "credit_usd": credit, "used_usd": used, "hours_left": left_h, "budget_24h": credit / hours * 24,
            "spent_24h": hermes_spent_24h(forge.db, external=True), "headroom": allowed_so_far - used,
            "expired": left_h <= 0, "pace": f"free credit ${credit:.0f}/{hours:.0f}h, used ${used:.2f}"}


def subscription_allowance(forge: Any, mode: dict[str, Any]) -> dict[str, Any]:
    """External subscription (Alibaba Token Plan / qwen3.8-max): prepaid plan, marginal cost ~bash until quota.
    Wakes must never be gated by FORGE DeepSeek balance. External call volume tracked for attribution."""
    spent = hermes_spent_24h(forge.db, external=True)
    calls = int(forge.db.scalar(
        "SELECT COUNT(*) FROM inference_calls WHERE agent LIKE 'hermes%' "
        "AND model NOT LIKE 'deepseek%' AND ts >= datetime('now','-1 day')") or 0)
    return {"mode": "subscription", "model": mode.get("model"), "provider": mode.get("provider", "alibaba-token-plan"),
            "budget_24h": None, "spent_24h": spent, "calls_24h": calls, "headroom": 1e6, "share": None,
            "pace": f"subscription {mode.get('provider', 'alibaba-token-plan')}: {calls} external calls/24h, quota enforced by provider"}


def hermes_allowance(forge: Any) -> dict[str, Any]:
    """Hermes' slice of the live intelligence pace: prior 40%, then proportional to measured value-per-$ vs FORGE's brain.
    In operator-credit mode (OP-018) the free credit pool is used instead."""
    mode = forge.db.kv_get("hermes.mode") or {}
    if mode.get("mode") == "credit":
        a = credit_allowance(forge, mode)
        if not a["expired"]:
            return a
    if mode.get("mode") == "subscription":
        return subscription_allowance(forge, mode)
    b = getattr(forge, "brain", None)
    if b is None:
        return {"wake": False, "reason": "no brain/DeepSeek configured"}
    p = b.pace()
    h_roi = max(b.roi(f"hermes_{r}") for r in HERMES_ROLES)
    f_roi = max(b.roi(r) for r in ("perception", "scientist"))
    share = min(0.7, max(0.1, HERMES_SHARE_PRIOR * h_roi / max(f_roi, 1e-6)))
    spent = hermes_spent_24h(forge.db, external=False)
    allow = p.budget_24h * share
    return {"budget_24h": allow, "spent_24h": spent, "headroom": allow - spent, "share": share,
            "hermes_value_per_usd": h_roi, "forge_value_per_usd": f_roi, "balance": b.balance, "pace": p.reason}


def digest(forge: Any, since: float, role: str | None = None) -> dict[str, Any]:
    """Compact change feed so Hermes pre-run scripts wake the LLM only when something economically meaningful happened."""
    from datetime import UTC, datetime
    iso = datetime.fromtimestamp(since, UTC).isoformat()
    db = forge.db
    ev = db.query("SELECT ts, product_id, event FROM listing_events WHERE ts >= ? ORDER BY id DESC LIMIT 50", (iso,))
    tr = db.query("SELECT ts, agent, message FROM timeline WHERE ts >= ? AND level IN ('warn','error') ORDER BY id DESC LIMIT 20",
                  (iso,))
    st = db.query("SELECT ts, strategy_id, from_population, to_population, reason FROM strategy_events WHERE ts >= ? ORDER BY ts DESC "
                  "LIMIT 20", (iso,)) if db.scalar("SELECT 1 FROM sqlite_master WHERE name='strategy_events'") else []
    settled = db.scalar("SELECT COUNT(*) FROM crossrail_signals WHERE status='SETTLED' AND settled_ts >= ?", (since,)) or 0
    sc = db.kv_get("crossrail.scorecard") or {}
    directives = db.query("SELECT id, role, priority, instruction FROM ops_directives WHERE status = 'OPEN' AND role IN (?, 'all')",
                          (role,)) if role else []
    crit = db.query(
        "SELECT id, role, priority, instruction FROM ops_directives WHERE status IN ('OPEN','DISPATCHED') "
        "AND priority IN ('critical','high') AND role IN (?, 'all')", (role,)) if role else []
    pending_handoff = 0
    try:
        pending_handoff = int(db.scalar(
            "SELECT COUNT(*) FROM agent_handoffs WHERE to_role=? AND status='PENDING'", (role,)) or 0) if role else 0
    except Exception:
        pending_handoff = 0
    emp = db.kv_get("agents.employment") or db.kv_get("agents.heartbeat") or {}
    sla_breach = False
    for r in (emp.get("detailed") or emp.get("roster") or []):
        if r.get("role") == role and (r.get("state") == "STALE_SLA_BREACH" or r.get("employment") == "STALE"):
            sla_breach = True
    vel = db.kv_get("velocity") or {}
    proven = float(vel.get("proven_usd_per_h") or 0)
    recovery_lever = bool(proven < 0.10 and role in (
        "governor", "alpha_inventor", "critic", "adversary", "scout", "treasury", "prediction", "execution", "ops"))
    prelive = db.kv_get("lab.prelive_proof") or {}
    prelive_block = str(prelive.get("verdict") or "").startswith("NO") and role in (
        "governor", "alpha_inventor", "doctor", "scout", "critic", "adversary")
    ed = db.kv_get("edge_decay") or {}
    decay_hit = bool(ed.get("actions")) and role in ("scout", "governor", "critic", "alpha_inventor")
    urgent = bool(crit or pending_handoff or sla_breach or prelive_block or decay_hit)
    meaningful = bool(ev or tr or st or settled >= 10 or directives or urgent or recovery_lever)
    return {"since": since, "now": time.time(), "listing_events": ev, "warnings": tr, "strategy_events": st,
            "ops_directives": directives, "open_critical": crit, "pending_handoff": pending_handoff,
            "sla_breach": sla_breach, "urgent": urgent, "recovery_lever": recovery_lever,
            "prelive_block": prelive_block,
            "crossrail_settled_since": settled,
            "crossrail": {k: sc.get(k) for k in ("calibration_n", "brier_model", "brier_market", "brier_stacked",
                                                 "model_weight_share", "signals")},
            "treasury": {k: forge.treasury.get(k) for k in ("equity_usd", "true_net_usd", "daily_pnl_usd")},
            "meaningful": meaningful}


def record_usage(forge: Any, b: dict[str, Any], role_override: str | None = None) -> dict[str, Any]:
    import hashlib
    if forge.db.scalar("SELECT 1 FROM inference_calls WHERE id=?", (str(b.get("api_request_id") or ""),)):
        return {"ok": True, "duplicate": True, "accounted_at_source": True}
    rid = "hermes_" + hashlib.sha1(str(b.get("api_request_id") or secrets.token_hex(8)).encode()).hexdigest()[:24]
    if forge.db.scalar("SELECT 1 FROM inference_calls WHERE id = ?", (rid,)):
        return {"ok": True, "duplicate": True}
    u = b.get("usage") or {}
    cache = int(u.get("prompt_cache_hit_tokens") or u.get("cache_read_input_tokens") or u.get("cache_read_tokens")
                or u.get("cached_tokens") or 0)
    if u.get("prompt_tokens") is not None:                 # OpenAI/DeepSeek shape: prompt includes cached
        prompt = int(u["prompt_tokens"])
    else:                                                  # Anthropic shape: input excludes cache reads
        prompt = int(u.get("input_tokens") or 0) + (cache if "cache_read_input_tokens" in u else 0)
    usage_n = {"prompt_tokens": prompt, "completion_tokens": int(u.get("completion_tokens") or u.get("output_tokens") or 0),
               "prompt_cache_hit_tokens": cache}
    model = str(b.get("model") or "deepseek-flash")
    from forge.agents.genome import canonical_role
    role = role_override or canonical_role(str(b.get("role") or "governor"))
    brain = getattr(forge, "brain", None)
    ext = EXTERNAL_PRICES.get(model) or (forge.db.kv_get("hermes.prices") or {}).get(model)
    if ext:      # list-price cost for value measurement; free operator credit → NOT a treasury expense
        cost = ((usage_n["prompt_tokens"] - usage_n["prompt_cache_hit_tokens"]) * ext["in"]
                + usage_n["prompt_cache_hit_tokens"] * ext["cache"] + usage_n["completion_tokens"] * ext["out"]) / 1e6
    else:
        cost = brain.c.cost(model if model in forge.s.deepseek.prices else "deepseek-flash", usage_n) if brain else 0.0
    forge.db.insert("inference_calls", {
        "id": rid, "ts": _now(), "agent": f"hermes_{role}", "purpose": str(b.get("purpose") or "hermes")[:80],
        "model": model, "effort": b.get("effort"), "prompt_version": f"session:{str(b.get('session_id') or 'na')[:60]}",
        "input_tokens": usage_n["prompt_tokens"], "cached_tokens": usage_n["prompt_cache_hit_tokens"],
        "output_tokens": usage_n["completion_tokens"], "cost_usd": f"{cost:.8f}", "latency_ms": int(b.get("latency_ms") or 0),
        "tool_calls": None, "result_class": "hermes", "strategy_id": None, "opportunity_id": None, "error": None})
    mode = forge.db.kv_get("hermes.mode") or {}
    # FQ0 ledger truth: the workforce runs on Alibaba Token Plan — a PREPAID FLAT subscription billed in
    # Credits. Marginal cash cost of a Hermes call is $0; the real cost is the fixed monthly plan fee, which
    # is booked as MEMBERSHIP (see surface.bill_membership). Posting a per-token list price as OPEX:INFERENCE
    # fabricated ~$4.4/day of expense that never left the treasury and dragged TRUE-NET negative (it alone was
    # ~74% of the $0.25/h milestone). `cost` is still recorded on the call row for value-per-$ measurement.
    subscription_covered = bool(mode.get("mode") == "subscription" and not model.startswith("deepseek"))
    free_credit = bool(ext and not model.startswith("deepseek") and mode.get("mode") == "credit"
                       and time.time() < float(mode.get("start", 0)) + float(mode.get("hours", 0)) * 3600)
    if cost > 0 and not free_credit and not subscription_covered:
        forge.ledger.record_opex(forge.book if forge.book in ("live", "paper") else "paper", "INFERENCE",
                                 Decimal(f"{cost:.8f}"), rid, memo=f"hermes {role}")
    return {"ok": True, "cost_usd": cost, "ledger_posted": bool(cost > 0 and not free_credit and not subscription_covered),
            "subscription_covered": subscription_covered}


def mount(app: FastAPI, forge: Any, token: str) -> None:
    from forge.brain.tools import TOOLS, ToolRouter

    def check(req: Request) -> None:
        if not is_agent_request(req, token):
            raise HTTPException(401, "agent token required")

    from forge.api.inference_proxy import mount as mount_inference
    mount_inference(app, forge, check)

    @app.get("/api/agent/tools")
    async def tools(request: Request) -> Any:
        check(request)
        return {"tools": TOOLS}

    @app.post("/api/agent/tool")
    async def tool(request: Request) -> Any:
        check(request)
        body = await request.json()
        from forge.agents.genome import canonical_role
        role = canonical_role(str(body.get("role") or "governor"))
        role = role if role in HERMES_ROLES else "governor"
        call_id = f"hermes:{str(body.get('session_id') or 'na')[:60]}"
        router = ToolRouter(forge, call_id, f"hermes_{role}")
        out = await router.dispatch(str(body.get("name", "")), json.dumps(body.get("args") or {}))
        for a in router.artifacts:
            pred = a.get("prediction")
            forge.db.insert("intel_artifacts", {"ts": _now(), "call_id": call_id, "role": f"hermes_{role}",
                                                "model": str(body.get("model") or "deepseek-flash"), "kind": a["kind"],
                                                "ref_id": a.get("ref_id"),
                                                "prediction": float(pred) if isinstance(pred, int | float) else None,
                                                "detail": None})
        return json.loads(out)

    @app.post("/api/agent/usage")
    async def usage(request: Request) -> Any:
        check(request)
        return record_usage(forge, await request.json())

    @app.get("/api/agent/allow")
    async def allow(request: Request, role: str = "governor", est_usd: float = 0.01) -> Any:
        check(request)
        a = hermes_allowance(forge)
        credit = a.get("mode") == "credit"
        # Hermes DeepSeek budget is separate from FORGE brain CRITICAL. Never silence the
        # institutional workforce when RED-ZONE recovery / SLA / open critical work exists.
        d = digest(forge, time.time() - 3600, role or None)
        urgent = bool(
            d.get("urgent") or d.get("recovery_lever") or d.get("sla_breach")
            or d.get("open_critical") or d.get("pending_handoff") or d.get("prelive_block")
        )
        headroom = float(a.get("headroom", 0) or 0)
        balance = float(a.get("balance") or 0)
        budget_ok = headroom >= float(est_usd)
        import math
        subscription = a.get("mode") == "subscription"
        a["wake"] = bool(math.isfinite(est_usd) and est_usd > 0 and budget_ok) and (
            credit or subscription or getattr(forge.brain, "tier", "") != "CRITICAL")
        a["wake_reason"] = "budget" if a["wake"] else "denied_budget_or_critical"
        # Urgency selects work within the budget; it cannot create credit.
        from forge.treasury.spend_admission import enabled
        if enabled(forge.db) and not subscription:
            sentinel = forge.db.kv_get("deepseek.sentinel") or {}
            from datetime import datetime
            try:
                fresh = 0 <= time.time() - datetime.fromisoformat(sentinel["checked"]).timestamp() <= 600
                floor = float(forge.s.deepseek.min_balance_reserve_usd)
                from forge.treasury.spend_admission import inference_runway
                from forge.treasury.intelligence import profit_7d
                global_budget = max(0., float(sentinel["balance"]) - floor) / inference_runway(forge.db)
                global_budget += max(0., profit_7d(forge.db)) * .25 / 7
                outstanding = float(forge.db.scalar("SELECT COALESCE(SUM(max_cost_usd),0) FROM spend_reservations "
                                                    "WHERE provider='deepseek' AND state IN ('RESERVED','UNCERTAIN')") or 0)
                from forge.treasury.intelligence import spent_24h
                global_head = global_budget - spent_24h(forge.db) - outstanding
                a.update(global_headroom_usd=global_head, outstanding_usd=outstanding)
                a["wake"] = a["wake"] and fresh and global_head >= est_usd
            except (KeyError, TypeError, ValueError):
                a["wake"] = False
                a["wake_reason"] = "provider_balance_unknown_or_stale"
        a["role"] = role
        a["urgent"] = urgent
        return a

    @app.get("/api/agent/digest")
    async def dig(request: Request, since: float = 0.0, role: str = "") -> Any:
        check(request)
        return digest(forge, since or time.time() - 3600, role or None)


def _now() -> str:
    from datetime import UTC, datetime
    return datetime.now(UTC).isoformat()
