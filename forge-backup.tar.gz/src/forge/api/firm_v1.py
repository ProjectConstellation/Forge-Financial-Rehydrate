"""Normalized firm API surface (blueprint §87) — wraps existing KV/state, no duplicates."""
from __future__ import annotations

import time
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder


def _j(data: Any) -> JSONResponse:
    return JSONResponse(jsonable_encoder(data))


def mount_firm_v1(app: FastAPI, forge: Any) -> None:
    @app.get("/api/v1/portfolios/capabilities")
    async def portfolio_capabilities() -> Any:
        from forge.treasury.capabilities import matrix
        return _j(matrix(forge))
    @app.get("/api/v1/research/results")
    async def research_results() -> Any:
        from forge.agents.research_accountability import research_board
        return _j(research_board(forge.db))

    @app.get("/api/v1/intelligence/economics")
    async def intelligence_economics(window: str = "24h") -> Any:
        from forge.ops.econ import window as economic_window
        from forge.agents.research_accountability import research_board
        return _j({"performance": economic_window(forge, window), "research": research_board(forge.db),
                   "capital": forge.db.kv_get("treasury.truth"),
                   "policy": forge.db.kv_get("intelligence.admission")})
    @app.get("/api/v1/treasury")
    async def v1_treasury() -> Any:
        return _j(forge.db.kv_get("treasury.truth") or {"error": "not_ready"})

    @app.get("/api/v1/treasury/reconcile")
    async def v1_reconcile() -> Any:
        t = forge.db.kv_get("treasury.truth") or {}
        return _j(t.get("reconciliation") or t)

    @app.get("/api/v1/performance")
    async def v1_perf(window: str = "1h") -> Any:
        from forge.ops.econ import window as econ_window
        try:
            return _j(econ_window(forge, window))
        except Exception as e:
            return _j({"error": str(e)[:200]})

    @app.get("/api/v1/strategies")
    async def v1_strategies() -> Any:
        return _j({
            "tcs": forge.db.kv_get("treasury.tcs"),
            "edge_decay": forge.db.kv_get("edge_decay"),
            "reallocation": forge.db.kv_get("capital.reallocation"),
        })

    @app.get("/api/v1/opportunities")
    async def v1_opps() -> Any:
        return _j({
            "allocation": forge.db.kv_get("surface.allocation"),
            "half_life": forge.db.kv_get("opportunity.half_life"),
            "algo_factory": forge.db.kv_get("research.algo_factory"),
            "velocity_priorities": (forge.db.kv_get("velocity") or {}).get("priorities"),
        })

    @app.get("/api/v1/workforce")
    async def v1_workforce() -> Any:
        return _j({
            "employment": forge.db.kv_get("agents.employment") or forge.db.kv_get("agents.heartbeat"),
            "results": forge.db.kv_get("lab.results_enforcer") or forge.db.kv_get("agents.results_scorecard"),
            "dispatch": forge.db.kv_get("lab.officer_dispatch"),
            "workflow": forge.db.kv_get("lab.workflow_engine"),
            "opportunity_memory": forge.db.kv_get("lab.opportunity_memory"),
            "luke_orchestration": forge.db.kv_get("lab.luke_orchestration"),
            "money_scorecard": forge.db.kv_get("lab.money_scorecard"),
            "kalshi": forge.db.kv_get("lab.kalshi_capital_policy"),
            "multi_venue": forge.db.kv_get("lab.multi_venue_mandate"),
            "events": forge.db.kv_get("lab.economic_events"),
            "ts": time.time(),
        })

    @app.get("/api/v1/workforce/results")
    async def v1_workforce_results() -> Any:
        return _j(forge.db.kv_get("lab.results_enforcer") or {"error": "not_ready"})

    @app.get("/api/v1/agents")
    async def v1_agents() -> Any:
        return _j(forge.db.kv_get("agents.heartbeat") or {})

    @app.get("/api/v1/research")
    async def v1_research() -> Any:
        return _j({
            "algo_factory": forge.db.kv_get("research.algo_factory"),
            "equity": forge.db.kv_get("equity.paper_research"),
            "modal": forge.compute.summary() if getattr(forge, "compute", None) else None,
        })

    @app.get("/api/v1/risk")
    async def v1_risk() -> Any:
        from forge.core import state as tstate
        return _j({
            "trading_state": tstate.trading_state(forge.db),
            "breakers": forge.breakers.blocking() if hasattr(forge, "breakers") else None,
            "red_zone": forge.db.kv_get("treasury.red_zone"),
        })

    @app.get("/api/v1/systems")
    async def v1_systems() -> Any:
        loops = forge.sup.snapshot() if hasattr(forge.sup, "snapshot") else []
        return _j({
            "mode_label": (forge.db.kv_get("treasury.truth") or {}).get("mode_label"),
            "forge_live_trading": (forge.db.kv_get("treasury.truth") or {}).get("forge_live_trading"),
            "loops": loops,
            "guardian": forge.db.kv_get("guardian.state"),
            "hermes_mode": forge.db.kv_get("hermes.mode"),
            "ready": True,
            "ts": time.time(),
        })

    @app.get("/api/v1/timeline")
    async def v1_timeline(limit: int = 50) -> Any:
        rows = forge.db.query(
            "SELECT ts, kind, summary FROM timeline ORDER BY ts DESC LIMIT ?", (min(limit, 200),)
        ) if hasattr(forge.db, "query") else []
        return _j({"events": rows})

    @app.get("/api/v1/lab/evidence")
    async def v1_evidence() -> Any:
        return _j(forge.db.kv_get("lab.evidence_board") or {"error": "not_ready"})

    @app.get("/api/v1/lab/paper")
    async def v1_paper_lab() -> Any:
        return _j({
            "paper_lab": forge.db.kv_get("lab.paper_lab"),
            "aggression": forge.db.kv_get("lab.paper_aggression"),
            "stable_pnl": forge.db.kv_get("lab.paper_stable_pnl"),
            "evidence": forge.db.kv_get("lab.evidence_board"),
            "position_vigil": forge.db.kv_get("lab.position_vigil"),
        })

    @app.get("/api/v1/lab/vigil")
    async def v1_vigil() -> Any:
        return _j(forge.db.kv_get("lab.position_vigil") or {"error": "not_ready"})

    @app.get("/api/v1/econ/tournament")
    async def v1_econ_tournament() -> Any:
        return _j({
            "trial": forge.db.kv_get("paper_trial"),
            "board": forge.db.kv_get("econ.treasury_board"),
            "orchestrator": forge.db.kv_get("lab.econ_orchestrator"),
            "reallocation": forge.db.kv_get("capital.reallocation"),
            "edge_decay": forge.db.kv_get("edge_decay"),
            "paper_bets": forge.db.kv_get("lab.paper_bets"),
            "modal": forge.db.kv_get("econ.modal_research"),
            "modal_attribution": forge.db.kv_get("econ.modal_attribution"),
            "prefer_rails": forge.db.kv_get("econ.prefer_rails"),
            "earnings_escalator": forge.db.kv_get("lab.earnings_escalator"),
            "membership_recommendation": forge.db.kv_get("membership.recommendation"),
            "prelive_proof": forge.db.kv_get("lab.prelive_proof"),
        })

    @app.get("/api/v1/lab/paper_bets")
    async def v1_paper_bets() -> Any:
        return _j(forge.db.kv_get("lab.paper_bets") or {"error": "not_ready"})


    @app.get("/api/v1/lab/dispatch")
    async def v1_dispatch() -> Any:
        return _j(forge.db.kv_get("lab.officer_dispatch") or {"error": "not_ready"})

    @app.get("/api/v1/intel/feeds")
    async def v1_intel_feeds() -> Any:
        return _j({
            "board": forge.db.kv_get("intel.feeds"),
            "edgar": forge.db.kv_get("intel.edgar"),
            "twelve_data": forge.db.kv_get("intel.twelve_data"),
            "odds_api": forge.db.kv_get("intel.odds_api"),
            "cred_links": forge.db.kv_get("ops.cred_pending_links"),
        })

    @app.get("/api/v1/trial/current")
    async def v1_trial() -> Any:
        return _j({
            "paper_trial": forge.db.kv_get("paper_trial"),
            "trial_8h": forge.db.kv_get("trial.8h"),
            "report": forge.db.kv_get("trial.8h.report"),
        })
