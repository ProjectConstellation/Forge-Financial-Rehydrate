"""Typed tool surface for DeepSeek (DOSSIER §18). Read tools return curated facts; action tools only queue validated
research artifacts. There is deliberately NO trade, transfer, risk-limit or emergency-stop tool (OP-009 §6)."""

from __future__ import annotations

import contextlib
import json
from typing import Any

from forge.core.ids import new_id
from forge.persistence.db import dumps
from forge.strategies.genome import Genome
from forge.strategies.registry import State


def _fn(name: str, desc: str, props: dict[str, Any], required: list[str] | None = None) -> dict[str, Any]:
    return {"type": "function", "function": {"name": name, "description": desc, "parameters": {
        "type": "object", "properties": props, "required": required or [], "additionalProperties": False}}}


TOOLS = [
    _fn("submit_paper_experiment", "Queue a typed equity hypothesis for automatic broker-paper trial, risk checks, measurement and rotation. No orders or LIVE authority.",
        {"objective_id": {"type":"string"}, "mechanism":{"type":"string","enum":["relative_momentum","dip_reversion","trend_following"]},
         "symbol":{"type":"string","enum":["QQQ","SPY","IWM","GLD","TLT"]},
         "lookback_sessions":{"type":"integer","enum":[10,20,40]}, "hypothesis":{"type":"string"}},
         ["objective_id","mechanism","hypothesis"]),
    _fn("get_research_results", "Measured research costs, decisions, paper experiments and automatic next actions; separate from LIVE income.", {}),
    _fn("get_system_state", "Treasury, capital regime, fees, mode, population counts, hurdle rate.", {}),
    _fn("get_market_state", "Live regime/feature snapshot for markets (latest bar).",
        {"symbols": {"type": "array", "items": {"type": "string"}}, "interval_s": {"type": "integer", "enum": [300, 3600]}}),
    _fn("list_strategies", "Strategies with state and evidence.",
        {"states": {"type": "array", "items": {"type": "string", "enum": [s.value for s in State]}}, "limit": {"type": "integer"}}),
    _fn("get_strategy", "Full genome, lineage, holdout/forward metrics and state history.", {"id": {"type": "string"}}, ["id"]),
    _fn("get_recent_failures", "Recent losing positions, demotions and gate failures with reasons.", {"limit": {"type": "integer"}}),
    _fn("get_missed_opportunities", "Counterfactual outcomes of rejected/observed opportunities (missed winners, avoided losers).",
        {"limit": {"type": "integer"}}),
    _fn("get_calibration", "Predicted-vs-actual reliability by prediction class.", {}),
    _fn("get_research_log", "Recent research notes/lessons (institutional memory).", {"limit": {"type": "integer"}}),
    _fn("submit_strategy_candidates", "Queue genomes for evaluation by the evolution engine (validated, backtested, gated).",
        {"candidates": {"type": "array", "items": {"type": "object"}}}, ["candidates"]),
    _fn("record_lesson", "Persist a structured lesson.", {"statement": {"type": "string"}, "confidence": {"type": "number"},
                                                          "family": {"type": "string"}}, ["statement", "confidence"]),
    _fn("request_research", "Ask the Improvement Loop to prioritize a horizon/focus next cycle.",
        {"interval_s": {"type": "integer", "enum": [300, 3600]}, "focus": {"type": "string"}}, ["focus"]),
    # OP-013 / Hermes dossier surfaces (shared by FORGE's brain and Hermes)
    _fn("get_opportunity_surface", "All income rails: status, executability, blockers, evidence-based score/day, allocator "
        "plan now vs if-unblocked, fixed costs (Coinbase One).", {}),
    _fn("get_crossrail_evidence", "Kalshi↔Coinbase prediction engine evidence: Brier model/market/stacked, settled shadow P&L by "
        "signal kind, lead/lag, edge half-life, RTI-proxy error, calibrator weights.", {}),
    _fn("get_profit_velocity", "FORGE PROFIT VELOCITY (the master KPI): realized true-net $/h (1h/4h/24h), expected $/h "
        "(live-now / proven / potential frontier), target, treasury regime, binding constraint, per-stream evidence tiers, "
        "scaling curve and ranked levers (marginal $/h of capital, proof, flow). Optimise research toward its top levers.", {}),
    _fn("get_shadow_rails", "Paper results of non-core rails (stable peg maker, stable triangle, listing discovery).", {}),
    _fn("get_listing_events", "Recent Coinbase product/listing/status/doc-page discovery events.", {"limit": {"type": "integer"}}),
    _fn("get_intelligence_budget", "Live DeepSeek balance, 24h pace/headroom, value-per-$ by role (incl. Hermes roles).", {}),
    # cognitive architecture (role briefs, structured reports, prompt genomes, blind panels)
    _fn("get_role_brief", "FIRST CALL OF EVERY RUN: your engineered role brief (constitution, mission, decision rights, "
        "evidence standard, output schema), live world state and your role's track record.", {"role": {"type": "string"}},
        ["role"]),
    _fn("submit_role_report", "LAST CALL OF EVERY RUN: structured role report (JSON object per your brief's output schema).",
        {"role": {"type": "string"}, "report": {"type": "object"}}, ["role", "report"]),
    _fn("get_recent_candidates", "LLM-designed strategy candidates with gate/sealed outcomes and inventor/adversary forecasts.",
        {"limit": {"type": "integer"}}),
    _fn("get_role_reports", "Recent structured reports of all roles (blind-panel verdicts hidden until reconciled).",
        {"limit": {"type": "integer"}, "role": {"type": "string"}}),
    _fn("get_prompt_performance", "Prompt genome versions per role with runs, KPI, cost, calibration and challenger status.",
        {"role": {"type": "string"}}),
    _fn("submit_prompt_variant", "Architect only: propose ONE challenger prompt variant (edit 1–3 sections) with a hypothesis.",
        {"role": {"type": "string"}, "parent_version": {"type": "integer"}, "hypothesis": {"type": "string"},
         "sections": {"type": "object"}}, ["role", "hypothesis", "sections"]),
    _fn("get_system_health", "Self-healing health: loop heartbeats, feed state, event-loop lag, quarantines, circuits, "
        "recent warnings/errors, memory.", {}),
    _fn("judge_ask", "STEP 1 of a typed judgement. Pass question_set (stable_edge | event_gap | spot_entry | "
        "pick | regime) and the candidate's `state`. Returns a strict JSON schema, the state PRUNED to only "
        "the fields those questions read, a plain-English gloss of each question, and the absolute "
        "worth-gate name. Answer in this same run — do NOT make another model call for it.",
        {"question_set": {"type": "string"}, "state": {"type": "object"}}, ["question_set", "state"]),
    _fn("judge_commit", "STEP 2 of a typed judgement. Pass the same question_set plus your `answers` exactly "
        "matching the schema from judge_ask. The desk validates them (never invents a number), calibrates "
        "every probability against realized outcomes, applies the absolute gate, and returns ACT / "
        "STAND_DOWN / REJECT with a size_factor. Act on size_factor; do not re-rank the winner.",
        {"question_set": {"type": "string"}, "answers": {"type": "object"}, "state": {"type": "object"},
         "candidate_id": {"type": "string"}}, ["question_set", "answers"]),
    _fn("get_arb_rail_status", "Status of the 24/7 CROSS-BOOKMAKER ARBITRAGE rail (sports/bets). Reports "
        "whether it is READY, BLOCKED_NO_KEY or BLOCKED_KEY_REJECTED, what the blocker is, and that the "
        "detector is built and mathematically proven. This is the structural-identity edge class (same "
        "outcome priced by two books must agree) applied to bets — the analog of the stable triangle.", {}),
    _fn("get_overnight_evidence", "The zero-inference overnight harness report: funnel replay (what free "
        "arithmetic kills), calibration audit (does our model beat the market), salary baseline (is each seat "
        "recouping its inference), crown-jewel lambda study, and the event-rail verdict. Refreshed every 2h. "
        "Read this before opining on what to improve — it is measured, not remembered.", {"section": {"type": "string"}},),
    _fn("judge_calibration", "Calibration health per question: evidence count n, base rate, raw Brier vs "
        "calibrated Brier, and the improvement calibration adds. A question whose calibration is not "
        "improving with enough n is not worth asking.", {}),
    _fn("funnel_health", "Filter health: rejections in 24h (under ~10 means the filter is misconfigured, "
        "not that the market is quiet), per-rung kill rates, and how many candidates are benched.", {}),
    _fn("salary_report", "The inference economy: per role, attributed income vs inference salary over the "
        "window, value_per_usd, and state (EARNING / WARN / CRITICAL / UNSCORED / PROTECTED). Inference is "
        "how a seat is paid; this is whether it earns its keep.", {}),
    _fn("submit_research_lead", "Record a research lead (new rail, fee/rule change, market-structure anomaly, data source) with "
        "sources; it is triaged by FORGE and valued if it leads to income.",
        {"title": {"type": "string"}, "body": {"type": "string"}, "category": {"type": "string"},
         "sources": {"type": "array", "items": {"type": "string"}}, "expected_value_usd_month": {"type": "number"}},
        ["title", "body", "category"]),
]


class ToolRouter:
    def __init__(self, forge: Any, call_id: str, role: str) -> None:
        self.f, self.call_id, self.role = forge, call_id, role
        self.artifacts: list[dict[str, Any]] = []

    async def dispatch(self, name: str, args_json: str) -> str:
        try:
            args = json.loads(args_json or "{}")
        except ValueError:
            return json.dumps({"error": "invalid JSON arguments"})
        fn = getattr(self, f"t_{name}", None)
        if fn is None:
            return json.dumps({"error": f"unknown tool {name}"})
        try:
            out = fn(**args)
        except TypeError as e:
            out = {"error": f"bad arguments: {e}"}
        except Exception as e:
            out = {"error": f"{type(e).__name__}: {str(e)[:200]}"}
        if name == "get_role_brief":
            # The brief is self-capped internally (world JSON 12k, memory 8k, contract 3.5k).
            # Truncating it destroys the structured payload every officer depends on
            # (governor's brief exceeded the old 30k cap and arrived as a truncated blob).
            return json.dumps(out, default=str)
        return _fit_json(out, 120000)

    # ---------------- read tools
    def t_get_system_state(self) -> dict[str, Any]:
        f = self.f
        t = f.treasury
        return {"mode": f.s.mode.value, "book": f.book, "treasury": {k: t.get(k) for k in (
            "equity_usd", "cash_usd", "deployed_usd", "true_net_usd", "fees_usd", "opex_inference_usd", "opex_compute_usd",
            "daily_pnl_usd", "reserve_usd")}, "capital_regime": t.get("regime"),
            "fees": {"maker": float(f.fees.maker), "taker": float(f.fees.taker)},
            "population": f.reg.counts(), "hurdle_per_day": f.hurdle.hurdle(1.0) * 24, "universe": f.universe}

    def t_get_market_state(self, symbols: list[str] | None = None, interval_s: int = 3600) -> dict[str, Any]:
        eng = self.f.bars.get(interval_s) or self.f.bars[3600]
        out = {}
        keys = ("ret_12", "ret_48", "ret_288", "vol_48", "vol_pct", "rvol_12", "er_24", "z_50", "rs_btc_48", "dd_288", "atr_14")
        for s in (symbols or self.f.universe)[:40]:
            st = eng.state.get(s)
            if not st or not st.features:
                continue
            out[s] = {"regime": st.regime, "regime_conf": round(st.regime_conf, 3),
                      "features": {k: round(float(st.features[k][-1]), 5) for k in keys if k in st.features
                                   and st.features[k][-1] == st.features[k][-1]}}
        return {"interval_s": interval_s, "markets": out}

    def t_list_strategies(self, states: list[str] | None = None, limit: int = 30) -> list[dict[str, Any]]:
        sts = tuple(State(s) for s in states) if states else None
        rows = self.f.reg.list(sts)
        rows.sort(key=lambda r: -(r[2].get("fitness") or -9))
        out = []
        for g, st, row in rows[: max(1, min(limit, 60))]:
            ev = self.f.arena.evidence(g.id)
            out.append({"id": g.id, "family": g.family, "state": st.value, "gen": g.generation, "fitness": row.get("fitness"),
                        "hypothesis": g.hypothesis[:200], "interval_s": g.interval_s,
                        "holdout": _short(self.f.reg.latest_metrics(g.id, "holdout")),
                        "evidence": ev.__dict__ if ev else None})
        return out

    def t_get_strategy(self, id: str) -> dict[str, Any]:
        g = self.f.reg.get(id)
        if g is None:
            q = self.f.db.kv_get("brain.candidate_queue", []) or []
            for i, item in enumerate(q):
                if item["genome"].get("id") == id:
                    return {"state": "PENDING_EVALUATION", "queue_position": i + 1, "queue_length": len(q),
                            "note": "queued for the next evolution cycle (≤ 12 LLM genomes per cycle per interval)",
                            "genome": item["genome"], "predicted_p": item.get("predicted_p")}
            return {"error": "not found (not in registry or evaluation queue; duplicates of existing DNA map to the "
                             "existing strategy id)"}
        return {"genome": g.model_dump(mode="json"), "state": self.f.reg.state(id), "lineage": self.f.reg.lineage(id, 3),
                "holdout": _short(self.f.reg.latest_metrics(id, "holdout")), "forward": _short(self.f.reg.latest_metrics(id, "forward"))}

    def t_get_recent_failures(self, limit: int = 20) -> dict[str, Any]:
        db = self.f.db
        return {"losing_positions": db.query("SELECT symbol, strategy_id, exit_reason, realized_pnl_usd, fees_usd, cost_usd, "
                                             "opened_at, closed_at FROM positions WHERE status='CLOSED' AND "
                                             "CAST(realized_pnl_usd AS REAL) - CAST(fees_usd AS REAL) < 0 ORDER BY closed_at DESC LIMIT ?", (limit,)),
                "demotions": db.query("SELECT strategy_id, ts, from_population, to_population, reason FROM strategy_events "
                                      "WHERE to_population IN ('SHADOW','EXPERIMENTAL','RETIRED','HIBERNATING') ORDER BY id DESC LIMIT ?", (limit,))}

    def t_get_missed_opportunities(self, limit: int = 40) -> list[dict[str, Any]]:
        rows = self.f.db.query("SELECT symbol, family, strategy_id, status, reason, probability, outcome FROM opportunities "
                               "WHERE outcome IS NOT NULL ORDER BY ts_ns DESC LIMIT ?", (limit,))
        for r in rows:
            r["outcome"] = json.loads(r["outcome"])
        return rows

    def t_get_calibration(self) -> list[dict[str, Any]]:
        return [{k: v for k, v in self.f.calib.reliability(c).items() if k != "table"} for c in self.f.calib.classes()]

    def t_get_research_log(self, limit: int = 15) -> list[dict[str, Any]]:
        return self.f.db.query("SELECT ts, author, kind, title, substr(body,1,600) AS body FROM research_notes "
                               "ORDER BY ts DESC LIMIT ?", (limit,))

    # ---------------- action tools (research artifacts only)
    def t_submit_strategy_candidates(self, candidates: list[dict[str, Any]]) -> dict[str, Any]:
        ok, bad = [], []
        queue = self.f.db.kv_get("brain.candidate_queue", []) or []
        for c in candidates[:12]:
            raw = c.get("genome", c)
            try:
                raw = {**raw, "id": new_id("stg"), "origin": "llm", "generation": int(raw.get("generation", 0)),
                       "parents": raw.get("parents", [])}
                g = Genome.model_validate(raw)
            except Exception as e:
                bad.append({"error": str(e)[:300]})
                continue
            queue.append({"genome": g.model_dump(mode="json"), "rationale": c.get("rationale", {}),
                          "predicted_p": c.get("predicted_holdout_p_positive"), "call_id": self.call_id, "role": self.role})
            ok.append(g.id)
            self.artifacts.append({"kind": "genome", "ref_id": g.id, "prediction": c.get("predicted_holdout_p_positive")})
        self.f.db.kv_set("brain.candidate_queue", queue[-60:])
        return {"queued": ok, "rejected": bad}

    def t_record_lesson(self, statement: str, confidence: float, family: str | None = None) -> dict[str, Any]:
        lid = new_id("les")
        self.f.db.insert("lessons", {"id": lid, "statement": statement[:1000], "family": family,
                                     "confidence": float(min(max(confidence, 0), 1)), "created_at": _now()})
        self.artifacts.append({"kind": "lesson", "ref_id": lid})
        return {"lesson_id": lid}

    # ---------------- cognitive architecture
    def _pg(self) -> Any:
        from forge.agents.genome import PromptGenomes
        return PromptGenomes(self.f)

    def _session(self) -> str:
        return self.call_id.split(":", 1)[1] if ":" in self.call_id else self.call_id

    def t_get_role_brief(self, role: str) -> dict[str, Any]:
        return self._pg().brief(role, self._session())

    def t_submit_role_report(self, role: str, report: dict[str, Any]) -> dict[str, Any]:
        out = self._pg().submit_report(role, self._session(), report if isinstance(report, dict) else {"raw": str(report)})
        self.artifacts.append({"kind": "role_report", "ref_id": out.get("prompt_id")})
        return out

    def t_get_recent_candidates(self, limit: int = 20) -> list[dict[str, Any]]:
        return self._pg().recent_candidates(limit)

    def t_get_role_reports(self, limit: int = 20, role: str | None = None) -> list[dict[str, Any]]:
        return self._pg().role_reports(self.role.replace("hermes_", ""), limit, role)

    def t_get_prompt_performance(self, role: str | None = None) -> list[dict[str, Any]]:
        return self._pg().performance(role)

    def t_submit_prompt_variant(self, role: str, hypothesis: str, sections: dict[str, str],
                                parent_version: int | None = None) -> dict[str, Any]:
        if not self.role.endswith("architect"):
            return {"error": "only the architect role may propose prompt variants"}
        out = self._pg().submit_variant(role, parent_version, hypothesis, sections, author=self.role)
        if out.get("prompt_id"):
            self.artifacts.append({"kind": "prompt_variant", "ref_id": out["prompt_id"]})
        return out

    # ---------------- arbitrage rail status (24/7 bets; structural identity edge)
    def t_get_arb_rail_status(self) -> dict[str, Any]:
        try:
            from forge.opportunities.paper_bets import PaperBetDesk
            desk = PaperBetDesk(self.f)
            st = desk.arb_status()
        except Exception as e:
            st = {"status": "ERROR", "error": f"{type(e).__name__}: {str(e)[:200]}"}
        st["founder_action"] = (
            "supply a working the-odds-api key via the one-time credential portal (never in chat) to make "
            "this 24/7 rail live — no code change needed"
            if str(st.get("status", "")).startswith("BLOCKED") else None)
        return st

    # ---------------- overnight evidence (zero-inference harness output)
    def t_get_overnight_evidence(self, section: str | None = None) -> dict[str, Any]:
        import json as _json
        import time as _t
        from pathlib import Path as _P
        base = _P("/srv/forge/var/reports/overnight")
        txt_path, json_path = base / "latest.txt", base / "latest.json"
        out: dict[str, Any] = {"dir": str(base), "exists": txt_path.exists()}
        if not txt_path.exists():
            out["error"] = ("no harness output yet; it runs every 2h via forge-overnight.timer "
                            "(systemctl status forge-overnight.timer)")
            return out
        try:
            mtime = txt_path.stat().st_mtime
            out["age_s"] = round(_t.time() - mtime, 1)
            out["generated_utc"] = _t.strftime("%Y-%m-%dT%H:%M:%SZ", _t.gmtime(mtime))
            out["stale"] = (_t.time() - mtime) > 4 * 3600
        except Exception:
            pass
        data: dict[str, Any] = {}
        if json_path.exists():
            try:
                data = _json.loads(json_path.read_text())
                out["stamp"] = data.get("stamp")
            except Exception as e:
                out["json_error"] = f"{type(e).__name__}: {e}"
        if section:
            key = str(section).strip()
            if key in data:
                out["section"] = key
                out["data"] = data[key]
            else:
                out["error"] = f"unknown section {key!r}"
                out["sections"] = [k for k in data if isinstance(data.get(k), dict)]
            return out
        # whole digest, bounded so it cannot swamp a brief
        try:
            txt = txt_path.read_text()
        except Exception as e:
            out["error"] = f"unreadable: {e}"
            return out
        out["digest"] = txt[:18000]
        out["digest_truncated"] = len(txt) > 18000
        return out

    # ---------------- Forge-Jev: typed judgement seats (no model call of their own)
    def t_judge_ask(self, question_set: str, state: dict[str, Any] | None = None) -> dict[str, Any]:
        from forge.judge import Judge
        try:
            j = Judge(self.f.db)
            return j.ask(question_set, state or {})
        except KeyError as e:
            return {"error": str(e)}
        except Exception as e:
            return {"error": f"{type(e).__name__}: {str(e)[:160]}"}

    def t_judge_commit(self, question_set: str, answers: dict[str, Any], state: dict[str, Any] | None = None,
                       candidate_id: str = "") -> dict[str, Any]:
        from forge.judge import Judge
        try:
            j = Judge(self.f.db)
            return j.commit(question_set, answers or {}, state=state or {}, role=self.role,
                            candidate_id=candidate_id or self.call_id, source=self.f.book)
        except KeyError as e:
            return {"error": str(e)}
        except Exception as e:
            return {"error": f"{type(e).__name__}: {str(e)[:160]}"}

    def t_judge_calibration(self) -> dict[str, Any]:
        from forge.judge import JudgeCalibrator
        cal = JudgeCalibrator(db=self.f.db)
        rows = cal.report()
        return {"n_questions": len(rows), "questions": rows[:40],
                "rule": "act on `calibrated`, never on `raw`; `provisional` (n<30) cuts ticket size"}

    def t_funnel_health(self) -> dict[str, Any]:
        from forge.judge.checks import default_funnel
        return default_funnel(self.f.db).health()

    def t_salary_report(self) -> dict[str, Any]:
        from forge.judge import InferenceEconomy
        eco = InferenceEconomy(self.f.db)
        ev = eco.evaluate_all()
        return {"paper_proof": eco._in_paper_proof(),
                "rule": "inference is a salary: attributed income must recoup it. Luca (ops) is never cut.",
                "roles": {r: {k: v.get(k) for k in ("state", "value_per_usd", "calls",
                                                     "attributed_income_usd", "inference_cost_usd", "note")}
                          for r, v in ev.items()}}

    def t_get_system_health(self) -> dict[str, Any]:
        f = self.f
        h = getattr(f, "health", None)
        warn = self.f.db.query("SELECT ts, agent, level, substr(message,1,240) AS message FROM timeline WHERE level IN "
                               "('warn','error') ORDER BY id DESC LIMIT 15")
        return {"score": h.score() if h else None, "loops": f.sup.snapshot() if hasattr(f.sup, "snapshot") else None,
                "quarantined": [r["key"].split(".", 1)[1] for r in self.f.db.query(
                    "SELECT key FROM kv_state WHERE key LIKE 'quarantine.%' AND value != 'null'")],
                "recent_warnings": warn, "bad_ticks_repaired_24h": self.f.db.scalar(
                    "SELECT COUNT(*) FROM listing_events WHERE event='BAD_TICK_REPAIRED' AND ts > ?",
                    (datetime_iso_hours_ago(24),))}

    def t_get_opportunity_surface(self) -> dict[str, Any]:
        db = self.f.db
        rails = db.query("SELECT id, category, status, executable, blockers, economics FROM rail_registry ORDER BY id")
        a = db.kv_get("surface.allocation") or {}
        return {"rails": [{**dict(r), "blockers": json.loads(r["blockers"] or "[]"),
                           "economics": json.loads(r["economics"] or "{}")} for r in rails],
                "now": a.get("now"), "unlock_value": a.get("unlock_value"), "fixed_costs": a.get("fixed_costs_usd_per_day"),
                "membership": db.kv_get("membership.coinbase_one")}

    def t_get_crossrail_evidence(self) -> dict[str, Any]:
        sc = self.f.db.kv_get("crossrail.scorecard") or {}
        return {**sc, "calibrator": self.f.db.kv_get("crossrail.calibrator"),
                "mapping": (self.f.db.kv_get("crossrail.mapping") or {}).get("mapped")}

    def t_get_profit_velocity(self) -> dict[str, Any]:
        v = dict(self.f.db.kv_get("velocity") or {})
        fr = v.pop("frontier", {}) or {}
        v["frontier"] = {k: {kk: vv for kk, vv in (f or {}).items() if kk != "streams"} | {"streams": (f or {}).get("streams", [])[:8]}
                         for k, f in fr.items()}
        return v

    def t_get_shadow_rails(self) -> dict[str, Any]:
        rows = self.f.db.query("SELECT rail, COUNT(*) n, SUM(pnl_usd) pnl, AVG(pnl_usd / (entry * qty)) mean_ret, "
                               "AVG(hold_s) hold_s FROM shadow_trades GROUP BY rail")
        return {"rails": rows, "pegmaker": self.f.db.kv_get("pegmaker.state")}

    def t_get_listing_events(self, limit: int = 30) -> list[dict[str, Any]]:
        return self.f.db.query("SELECT ts, product_id, product_type, event, after FROM listing_events ORDER BY id DESC LIMIT ?",
                               (min(int(limit), 200),))

    def t_get_intelligence_budget(self) -> dict[str, Any]:
        b = getattr(self.f, "brain", None)
        roles = self.f.db.query("SELECT agent, COUNT(*) n, SUM(CAST(cost_usd AS REAL)) usd FROM inference_calls GROUP BY agent")
        return {"pace": self.f.db.kv_get("brain.pace"), "balance": getattr(b, "balance", None),
                "spend_by_agent": roles, "roi": {r: b.roi(r) for r in ("perception", "scientist", "hermes_governor",
                                                                     "hermes_alpha_inventor", "hermes_adversary", "hermes_rail_hunter")} if b else None}

    def t_submit_research_lead(self, title: str, body: str, category: str, sources: list[str] | None = None,
                               expected_value_usd_month: float | None = None) -> dict[str, Any]:
        lid = new_id("lead")
        self.f.db.insert("research_notes", {"id": lid, "ts": _now(), "author": self.role, "kind": f"lead:{category[:40]}",
                                            "title": title[:200], "body": json.dumps({"body": body[:4000], "sources": (sources or [])[:10],
                                                                                      "ev_usd_month": expected_value_usd_month})})
        self.artifacts.append({"kind": "lead", "ref_id": lid})
        if category.startswith(("report", "operator_action", "incident", "new_rail", "fee_change")):
            import asyncio
            agent = "Hermes" if self.role.startswith("hermes") else "DeepSeek Brain"
            msg = f"[{category}] {title[:120]}" + (f" — {body[:600]}" if category.startswith("report") else "")
            with contextlib.suppress(RuntimeError):
                asyncio.get_running_loop().create_task(self.f.say(agent, msg))
        return {"lead_id": lid}

    def t_request_research(self, focus: str, interval_s: int | None = None) -> dict[str, Any]:
        self.f.db.kv_set("brain.research_focus", {"focus": focus[:300], "interval_s": interval_s, "by": self.call_id})
        self.artifacts.append({"kind": "research_focus", "ref_id": focus[:60]})
        return {"ok": True}

    def t_get_research_results(self):
        from forge.agents.research_accountability import research_board
        return research_board(self.f.db)

    def t_submit_paper_experiment(self, **proposal):
        from forge.research.experiment_registry import PaperHypothesis, queue_paper_hypothesis
        result=queue_paper_hypothesis(self.f.db,PaperHypothesis.model_validate(proposal),self.role)
        self.artifacts.append({"kind":"paper_experiment_proposal","ref_id":result['id']})
        return result


def _short(m: dict[str, Any] | None) -> dict[str, Any] | None:
    if not m:
        return None
    keep = ("n", "mean_net", "win_rate", "p_positive", "alpha_mean", "alpha_p_positive", "drift_mean", "avg_hold_h",
            "log_per_capital_day", "max_dd", "profit_factor")
    return {k: m.get(k) for k in keep if k in m}


def _now() -> str:
    from datetime import UTC, datetime
    return datetime.now(UTC).isoformat()


__all__ = ["TOOLS", "ToolRouter", "dumps"]


def datetime_iso_hours_ago(h: float) -> str:
    from datetime import UTC, datetime, timedelta
    return (datetime.now(UTC) - timedelta(hours=h)).isoformat()


def _fit_json(out: Any, limit: int) -> str:
    """Serialize tool output within `limit` chars while ALWAYS staying valid JSON (truncated JSON broke callers → HTTP 500)."""
    txt = json.dumps(out, default=str)
    if len(txt) <= limit:
        return txt
    if isinstance(out, list):
        lo, hi = 0, len(out)
        while lo < hi:                                     # largest prefix of items that fits
            mid = (lo + hi + 1) // 2
            if len(json.dumps({"items": out[:mid], "truncated": True, "total": len(out)}, default=str)) <= limit:
                lo = mid
            else:
                hi = mid - 1
        return json.dumps({"items": out[:lo], "truncated": True, "total": len(out),
                           "note": f"showing {lo}/{len(out)}; ask with a smaller limit or a filter"}, default=str)
    return json.dumps({"truncated": True, "preview": txt[: limit - 200]}, default=str)
