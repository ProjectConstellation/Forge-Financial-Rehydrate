"""Earnings Push — deterministic under-target actuation (PAPER only).

Puts capital-hours on evidenced stables, cuts spot drains, advances stuck
alpha workflows with a typed intelligence packet, and recycles event desk.
"""
from __future__ import annotations

import json
import logging
import time
from typing import Any

log = logging.getLogger("forge.earnings_push")


class EarningsPush:
    def __init__(self, forge: Any) -> None:
        self.f = forge

    def _proven(self) -> float:
        vel = self.f.db.kv_get("velocity") or {}
        return float((vel.get("expected_usd_per_h") or {}).get("proven") or 0.0)

    def tick(self) -> dict[str, Any]:
        db = self.f.db
        now = time.time()
        proven = self._proven()
        nav = float((db.kv_get("econ.treasury_board") or {}).get("nav") or 0)
        actions: list[dict[str, Any]] = []

        # FQ0 / C3 RATE-THEN-SCALE: size the stables band to ACTUAL deployable capital.
        # The prior hard-coded [200,500]/[100,300] bands were 10-48x the real ~$10 treasury, so every
        # EARNINGS_PUSH was correctly rejected INFEASIBLE (Adversary/Treasury, 7 wakes) -> nothing
        # ever deployed (capital_utilization 0.0) while burning xhigh inference re-rejecting it.
        # Band now tracks real deployable, floored so a push is always fundable. As the founder
        # deposits capital, deployable rises and the band scales up automatically (RATE-THEN-SCALE).
        vel = db.kv_get("velocity") or {}
        deployable = float((vel.get("regime") or {}).get("deployable") or nav or 0.0)
        band_lo = max(2.0, round(deployable * 0.50, 2))
        band_hi = max(band_lo * 1.5, round(deployable * 0.90, 2))
        target_band = [band_lo, band_hi]

        # Capital policy: hard-prefer stables band, scaled to real deployable
        db.kv_set("lab.stable_capital_policy", {
            "target_band_usd": target_band,
            "multiplier": 3.0,
            "deployable_usd": deployable,
            "prefer": ["coinbase.stable_peg_mm", "coinbase.stable_triangle"],
            "mode": "EARNINGS_PUSH",
            "ts": now,
        })
        db.kv_set("econ.prefer_rails", {
            "order": ["coinbase.stable_peg_mm", "coinbase.stable_triangle", "odds.paper_h2h"],
            "paper_band_usd": target_band,
            "aggression": "EARNINGS_PUSH",
            "block_spot_challengers_when_proven_lt": 0.25,
            "ts": now,
        })
        actions.append({"prefer_rails": "stables_first"})

        # Force-exit losing / stagnant non-stable PAPER spot so capital recirculates
        rows = db.query(
            "SELECT id, symbol, strategy_id, cost_usd, meta, opened_at, entry_price, qty FROM positions "
            "WHERE book='paper' AND status!='CLOSED' LIMIT 30"
        ) or []
        # FQ0 ledger truth: this cut MUST use ACTUAL mark-to-market, never meta["loss"].
        # meta["loss"] is the MODELED worst-case loss leg supplied to position SIZING (the stop distance
        # used by the VA/Kelly assessor) — it is < -2% by construction, so the prior `loss < -0.02` test
        # force-exited essentially every position within seconds of opening. Measured damage: 70 positions
        # cut, median hold 124.9s (14 under 60s), $1.4020 of fees paid to realize -$0.0671 = a 20.9x fee
        # tax, and capital_utilization pinned at 0.0 because nothing lived long enough to accumulate
        # forward evidence — starving the entire deploy loop. The gateway already enforces the real
        # stop-loss from live marks (bbo.bid <= stop) via the position's exit plan, so this sweep only
        # needs to clear genuinely unrealized losers and truly stagnant inventory, and must take NO
        # action when no mark is available rather than inventing a loss.
        market = getattr(self.f, "market", None)
        for r in rows:
            meta = {}
            try:
                meta = json.loads(r.get("meta") or "{}")
            except Exception:
                pass
            fam = str(meta.get("family") or "")
            if "stable" in fam.lower():
                continue
            opened = float(meta.get("opened_ts") or 0)
            age_h = (now - opened) / 3600 if opened else 99

            # Actual unrealized return: live bid vs our entry mark.
            unreal = None
            try:
                bbo = market.get_bbo(r["symbol"]) if market is not None else None
                bid = float(getattr(bbo, "bid", 0) or 0) if bbo is not None else 0.0
                entry = float(meta.get("decision_mid") or r.get("entry_price") or 0)
                if bid > 0 and entry > 0:
                    unreal = bid / entry - 1.0
            except Exception:
                unreal = None

            real_loser = unreal is not None and unreal < -0.02
            stagnant = unreal is None and proven < 0.25 and age_h > 2.0
            if not (real_loser or stagnant):
                continue
            pct = round(unreal * 100, 3) if unreal is not None else None
            db.kv_set(f"position.force_exit.{r['id']}", {
                "ts": now, "reason": "earnings_push_cut_drain", "family": fam,
                "unrealized_pct": pct, "age_h": round(age_h, 2),
                "basis": "mark_to_market" if real_loser else "stagnant_no_mark",
            })
            actions.append({"force_exit": r["id"], "symbol": r["symbol"],
                            "unrealized_pct": pct, "age_h": round(age_h, 2)})

        # Paper lab intensify
        pl = getattr(self.f, "paper_lab", None)
        if pl:
            for name in ("ensure_stable_strategies", "bridge_stable_shadow_to_paper",
                         "kill_confirmed_drains", "reap_dead_positions", "promote_paper_probes"):
                fn = getattr(pl, name, None)
                if callable(fn):
                    try:
                        actions.append({name: fn()})
                    except Exception as e:
                        actions.append({name: f"err:{e}"[:100]})

        # Settle / recycle event PAPER if possible
        pb = getattr(self.f, "paper_bets", None)
        if pb:
            for name in ("settle", "tick", "scan_and_place", "run_once"):
                fn = getattr(pb, name, None)
                if callable(fn):
                    try:
                        out = fn()
                        actions.append({f"paper_bets.{name}": out if not hasattr(out, "__await__") else "async"})
                        break
                    except TypeError:
                        continue
                    except Exception as e:
                        actions.append({f"paper_bets.{name}": f"err:{e}"[:100]})

        # Memory gates CLAIMS not PAPER capital-hours. Desk must keep printing measurement P&L 24/7.
        claim_proven = True
        try:
            from forge.agents.opportunity_memory import OpportunityMemory
            om = getattr(self.f, "opportunity_memory", None) or OpportunityMemory(self.f)
            blk = om.blocks_income_claim("stable_triangle", "coinbase.stable_triangle")
            if blk:
                claim_proven = False
                actions.append({"memory": "CONTAMINATED_or_KILLED — keep PAPER hours; forbid proven-claim language",
                                "status": blk.get("status")})
                db.kv_set("lab.stable_capital_policy", {
                    "ts": now, "mode": "MEASUREMENT_PAPER",
                    "target_band_usd": target_band,  # scaled to real deployable (RATE-THEN-SCALE)
                    "deployable_usd": deployable,
                    "claim_proven": False,
                    "reason": blk.get("reason"),
                })
        except Exception as e:
            actions.append({"memory_check_err": str(e)[:120]})
        if claim_proven:
            db.kv_set("lab.stable_capital_policy", {
                "ts": now, "mode": "INCOME_PAPER", "target_band_usd": target_band,
                "deployable_usd": deployable, "claim_proven": True,
            })

        # Feed Tess evidence — NEVER auto-advance OPPORTUNITY_ORCHESTRATION past her proposal.
        # Only auto-advance ALPHA_GENERATION MARKET_INTELLIGENCE_PACKET if truly stuck (>25m).
        pending = db.query(
            "SELECT h.handoff_id, h.workflow_id, h.to_role, h.payload_type, h.created_at, w.type AS wf_type "
            "FROM agent_handoffs h LEFT JOIN agent_workflows w ON w.workflow_id=h.workflow_id "
            "WHERE h.status='PENDING' AND h.to_role='scout' LIMIT 8"
        ) or []
        stable = db.kv_get("lab.paper_stable_pnl") or {}
        tri = (stable.get("by_rail") or {}).get("coinbase.stable_triangle") or {}
        packet = {
            "trigger": "EARNINGS_PUSH",
            "rail": "coinbase.stable_triangle",
            "evidence": {
                "stable_triangle_net": tri.get("net"),
                "stable_triangle_n": tri.get("n"),
                "paper_stable_net": stable.get("net"),
                "proven_usd_per_h": proven,
                "nav": nav,
            },
            "recommendation": "MAXIMIZE_STABLES_PAPER_CAPITAL_HOURS",
            "next_action": "Quinn invents only fee-aware stables challengers; Ada gates; do not promote spot drains",
            "evidence_refs": ["lab.paper_stable_pnl", "shadow_trades:coinbase.stable_triangle", "velocity"],
            "economic_attribution": {"sleeve": "coinbase.stable_triangle", "mode": "PAPER_SHADOW"},
        }
        wf_engine = getattr(self.f, "workflow_engine", None)
        for h in pending:
            h = dict(h)
            wtype = h.get("wf_type") or ""
            ptype = h.get("payload_type") or ""
            # Opportunity masterpiece: leave for Tess; inject evidence into workflow inputs + directive
            if wtype == "OPPORTUNITY_ORCHESTRATION" or ptype in ("OPPORTUNITY_PROPOSAL", "MEASURE_RESULT"):
                db.kv_set("lab.scout_evidence_feed", {**packet, "ts": now, "for_workflow": h["workflow_id"]})
                db.execute(
                    "INSERT INTO ops_directives(ts,role,instruction,priority,status,requested_by) "
                    "VALUES(?,?,?,?,?,?)",
                    (now, "scout",
                     f"EVIDENCE_FEED for {h['workflow_id']} ({ptype}): stables triangle n={tri.get('n')} "
                     f"net={tri.get('net')} proven={proven}/h nav={nav}. Propose fundable "
                     f"STRATEGY|ALGORITHM|INVESTMENT|REALLOCATION — do not skip risk/capital gates. "
                     f"role=scout only.",
                     "high", "OPEN", "earnings_push"),
                )
                actions.append({"scout_evidence_feed": h["workflow_id"]})
                continue
            # Alpha path only: auto-advance MARKET_INTELLIGENCE if stuck >25m
            age = now - float(h.get("created_at") or now)
            if ptype == "MARKET_INTELLIGENCE_PACKET" and age > 1500 and wf_engine and hasattr(wf_engine, "advance"):
                try:
                    out = wf_engine.advance(
                        h["workflow_id"], "scout", "MARKET_INTELLIGENCE_PACKET",
                        packet, result_type="DECISION_MADE", confidence=0.7,
                    )
                    actions.append({"workflow_advance": out})
                except Exception as e:
                    actions.append({"workflow_advance_err": str(e)[:120]})

        # Direct pages — IMPLEMENT not analyze
        if proven < 0.10:
            paged = 0
            for role, instr in (
                ("governor", "EARNINGS_PUSH: keep PAPER capital-hours on stables measurement sleeve (do not claim proven if memory CONTAMINATED). Cut spot challengers. Report Δ$/h."),
                ("alpha_inventor", "EARNINGS_PUSH: only stables microstructure challengers. No alt breakout genomes until proven≥$0.25/h."),
                ("execution", "EARNINGS_PUSH: Reid — ensure pegmaker/triangle path is the active execution sleeve; abort fee-toxic spot."),
                ("treasury", "EARNINGS_PUSH: Ellis — opportunity cost of $1 off stables is the binding constraint. Prefer stables band $200–500."),
                ("scout", "EARNINGS_PUSH: Tess — if OPPORTUNITY_PROPOSAL pending, propose fundable ask using stables evidence; else MEASURE_RESULT on capital-hours. role=scout."),
            ):
                # Idempotent: one OPEN directive per distinct instruction per role. Previously this
                # raw INSERT ran every tick, producing 1,351 identical OPEN "critical" pages per role
                # (17,491 OPEN vs 1,573 DONE firm-wide) that drowned every agent brief and woke
                # officers to find nothing new — inference burned, no results.
                from forge.agents.directives import emit
                created = emit(db, role, instr, "critical", "earnings_push")
                if created:
                    paged += 1
            actions.append({"paged": paged})

        # Modal research on stables only
        db.kv_set("modal.research_request", {
            "ts": now,
            "reason": "earnings_push",
            "workloads": ["stable_microstructure_sweep", "stable_triangle_param_search"],
            "prefer_cpu": True,
            "consumed": False,
        })

        rep = {"ts": now, "proven": proven, "nav": nav, "actions": actions[:40],
               "policy": "stables_capital_hours_first_PAPER_only"}
        db.kv_set("lab.earnings_push", rep)
        if actions:
            log.info("earnings_push: %s", actions[:8])
        return rep

    async def run(self) -> None:
        import asyncio
        while not self.f.stop_event.is_set():
            self.f.sup.beat("earnings_push")
            try:
                await asyncio.to_thread(self.tick)
            except Exception as e:
                log.warning("earnings_push: %s", e, exc_info=True)
            await asyncio.sleep(120)
